<?php
session_start();

// Check if student is registered
if (!isset($_SESSION['student_id'])) {
    header("Location: index.php");
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Registration Successful</title>
    <style>
        body {
            background-color: #eceded;
            padding: 20px;
            font-family: Arial, sans-serif;
        }
        .success-container {
            background-color: #e8f5e9;
            border: 2px solid #388e3c;
            border-radius: 8px;
            padding: 30px;
            max-width: 500px;
            margin: 50px auto;
            text-align: center;
        }
        .success-container h1 {
            color: #388e3c;
            margin-bottom: 20px;
        }
        .success-container p {
            font-size: 18px;
            color: #333;
            margin: 10px 0;
        }
        .success-icon {
            font-size: 50px;
            margin-bottom: 20px;
        }
        .button {
            display: inline-block;
            margin-top: 20px;
            padding: 10px 20px;
            background-color: #388e3c;
            color: white;
            text-decoration: none;
            border-radius: 4px;
            font-size: 16px;
        }
        .button:hover {
            background-color: #2e7d32;
        }
    </style>
</head>
<body>
    <div class="success-container">
        <div class="success-icon">✓</div>
        <h1>Registration Successful!</h1>
        <p><strong>Welcome, <?php echo htmlspecialchars($_SESSION['student_name']); ?>!</strong></p>
        <p>Your student ID: <strong><?php echo $_SESSION['student_id']; ?></strong></p>
        <p>Your registration has been submitted successfully.</p>
        <p>You will receive details on your registered email.</p>
        
        <a href="index.php" class="button">Register Another Student</a>
        <a href="index.php" class="button" style="margin-left: 10px;">Back to Home</a>
    </div>
</body>
</html>
