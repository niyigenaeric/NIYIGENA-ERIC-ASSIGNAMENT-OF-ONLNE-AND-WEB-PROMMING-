-- phpMyAdmin SQL Dump
-- version 5.0.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3306
-- Generation Time: Apr 19, 2026 at 06:34 PM
-- Server version: 8.0.21
-- PHP Version: 7.3.21

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `student_registration`
--

-- --------------------------------------------------------

--
-- Table structure for table `qualifications`
--

DROP TABLE IF EXISTS `qualifications`;
CREATE TABLE IF NOT EXISTS `qualifications` (
  `id` int NOT NULL AUTO_INCREMENT,
  `student_id` int DEFAULT NULL,
  `level` varchar(50) DEFAULT NULL,
  `board` varchar(100) DEFAULT NULL,
  `percentage` float DEFAULT NULL,
  `passing_year` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `student_id` (`student_id`)
) ;

--
-- Dumping data for table `qualifications`
--

INSERT INTO `qualifications` (`id`, `student_id`, `level`, `board`, `percentage`, `passing_year`) VALUES
(1, 1, 'Class XII', '0', 20, '2023'),
(2, 2, 'Graduation', '0', 12, '2024'),
(3, 3, 'Class X', '0', 12, '2024'),
(4, 4, 'Class X', '0', 87, '2009'),
(5, 4, 'Class XII', '0', 70, '2014'),
(6, 4, 'Graduation', '0', 75, '2024'),
(7, 5, 'Class X', '0', 70, '2026'),
(8, 5, 'Class XII', '0', NULL, '');

-- --------------------------------------------------------

--
-- Table structure for table `students`
--

DROP TABLE IF EXISTS `students`;
CREATE TABLE IF NOT EXISTS `students` (
  `id` int NOT NULL AUTO_INCREMENT,
  `first_name` varchar(50) NOT NULL,
  `last_name` varchar(50) NOT NULL,
  `dob` date NOT NULL,
  `mobile_number` varchar(15) NOT NULL,
  `gender` varchar(10) NOT NULL,
  `address` text NOT NULL,
  `city` varchar(50) NOT NULL,
  `pin_code` varchar(10) NOT NULL,
  `state` varchar(50) NOT NULL,
  `country` varchar(50) NOT NULL,
  `hobbies` varchar(255) DEFAULT NULL,
  `courses_applied` varchar(255) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `email` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `students`
--

INSERT INTO `students` (`id`, `first_name`, `last_name`, `dob`, `mobile_number`, `gender`, `address`, `city`, `pin_code`, `state`, `country`, `hobbies`, `courses_applied`, `created_at`, `email`) VALUES
(1, 'NIYITEGEKA', 'Albertine', '2023-03-02', '0795776299', 'Male', 'BURERA/RUSARABUYE/ NDAGO', 'BURERA', '3456', 'dgfh', 'Rwanda', 'Singing', 'BCA', '2026-04-10 17:07:01', ''),
(2, 'NIYITEGEKA', 'Albertine', '2023-03-02', '0795776299', 'Male', 'BURERA/RUSARABUYE/ NDAGO', 'BURERA', '3456', 'dgfh', 'Rwanda', 'Sketching (dfgh)', 'BCA', '2026-04-10 17:09:40', ''),
(3, 'NIYITEGEKA', 'Albertine', '2026-02-02', '0795776299', 'Male', 'BURERA/RUSARABUYE/ NDAGO', 'BURERA', '3456', 'dgfh', 'Rwanda', 'Singing', 'BCA', '2026-04-10 17:21:15', 'niiii@gmail.com'),
(4, 'NIYITEGEKA', 'Albertine', '2016-01-12', '0795776299', 'Female', 'BURERA/RUSARABUYE/ NDAGO', 'BURERA', '3456', 'dgfh', 'Rwanda', 'Singing', 'BCA, B.Com, B.Sc', '2026-04-10 17:27:15', 'albertinenyawe@gmail.com'),
(5, 'NIYITEGEKA', 'niyigena', '2025-02-02', '0795776299', 'Female', 'BURERA/RUSARABUYE/ NDAGO', 'BURERA', '3456', 'dgfh', 'Rwanda', 'Dancing', 'B.Com', '2026-04-18 15:14:24', 'niyigenaeric532@gmail.com');
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
