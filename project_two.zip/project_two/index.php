<?php
session_start();
require_once 'db.php';
$errors = array();
$success = false;
$formData = array();

if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['submit'])) {
    
    // Sanitize and validate inputs
    $firstName = trim($_POST['firstName'] ?? '');
    $lastName = trim($_POST['lastName'] ?? '');
    $email = trim($_POST['email'] ?? '');
    $day = $_POST['day'] ?? '';
    $month = $_POST['month'] ?? '';
    $year = $_POST['year'] ?? '';
    $mobileNumber = trim($_POST['mobileNumber'] ?? '');
    $gender = $_POST['gender'] ?? '';
    $address = trim($_POST['comment'] ?? '');
    $city = trim($_POST['City'] ?? '');
    $pinCode = trim($_POST['pinCode'] ?? '');
    $state = trim($_POST['state'] ?? '');
    $country = trim($_POST['country'] ?? '');
    $hobbies = $_POST['hobbies'] ?? '';
    $otherHobbies = trim($_POST['otherhobbies'] ?? '');
    
    // Qualifications
    $classX_board = trim($_POST['class1'] ?? '');
    $classX_percentage = $_POST['percentage1'] ?? '';
    $classX_year = trim($_POST['year1'] ?? '');
    
    $classXII_board = trim($_POST['class2'] ?? '');
    $classXII_percentage = $_POST['percentage2'] ?? '';
    $classXII_year = trim($_POST['year2'] ?? '');
    
    $graduation_board = trim($_POST['class3'] ?? '');
    $graduation_percentage = $_POST['percentage3'] ?? '';
    $graduation_year = trim($_POST['year3'] ?? '');
    
    $masters_board = trim($_POST['mastersBoard'] ?? '');
    $masters_percentage = $_POST['mastersPercentage'] ?? '';
    $masters_year = trim($_POST['mastersYear'] ?? '');
    
    // Courses
    $courses = array();
    if (isset($_POST['bca']) && $_POST['bca'] == 'BCA') $courses[] = 'BCA';
    if (isset($_POST['bcom']) && $_POST['bcom'] == 'B.Com') $courses[] = 'B.Com';
    if (isset($_POST['bsc']) && $_POST['bsc'] == 'B.Sc') $courses[] = 'B.Sc';
    if (isset($_POST['ba']) && $_POST['ba'] == 'B.A') $courses[] = 'B.A';
    
    // Validation
    if (empty($firstName)) {
        $errors[] = "First Name is required";
    }
    if (empty($lastName)) {
        $errors[] = "Last Name is required";
    }
    if (empty($email)) {
        $errors[] = "Email is required";
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $errors[] = "Invalid email format";
    } elseif (!isset($conn)) {
        $errors[] = "Database connection error";
    } else {
        // Check if email already exists
        $check_email = $conn->prepare("SELECT id FROM students WHERE email = ?");
        $check_email->bind_param("s", $email);
        $check_email->execute();
        $check_email->store_result();
        if ($check_email->num_rows > 0) {
            $errors[] = "Email already registered. Please use a different email.";
        }
        $check_email->close();
    }
    if (empty($day) || empty($month) || empty($year)) {
        $errors[] = "Date of Birth is required";
    }
    if (empty($mobileNumber)) {
        $errors[] = "Mobile Number is required";
    } elseif (!preg_match('/^[0-9]{10}$/', $mobileNumber)) {
        $errors[] = "Mobile Number must be 10 digits";
    }
    if (empty($gender)) {
        $errors[] = "Gender is required";
    }
    if (empty($address)) {
        $errors[] = "Address is required";
    }
    if (empty($city)) {
        $errors[] = "City is required";
    }
    if (empty($pinCode)) {
        $errors[] = "Pin Code is required";
    }
    if (empty($state)) {
        $errors[] = "State is required";
    }
    if (empty($country)) {
        $errors[] = "Country is required";
    }
    if (empty($hobbies) && empty($otherHobbies)) {
        $errors[] = "Please select at least one hobby";
    }
    if (empty($courses)) {
        $errors[] = "Please select at least one course";
    }
    
    // If no errors, process the form
    if (empty($errors)) {
        // Convert date to proper format
        $dob = $year . '-' . str_pad($month, 2, '0', STR_PAD_LEFT) . '-' . str_pad($day, 2, '0', STR_PAD_LEFT);
        $hobbies_str = $hobbies . ($otherHobbies ? " ($otherHobbies)" : '');
        $coursesApplied = implode(', ', $courses);
        
        // Prepare and execute student registration query
        $stmt = $conn->prepare("INSERT INTO students (first_name, last_name, email, dob, mobile_number, gender, address, city, pin_code, state, country, hobbies, courses_applied) 
                                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
        
        if (!$stmt) {
            $errors[] = "Database error: " . $conn->error;
        } else {
            $stmt->bind_param("sssssssssssss", $firstName, $lastName, $email, $dob, $mobileNumber, $gender, $address, $city, $pinCode, $state, $country, $hobbies_str, $coursesApplied);
            
            if ($stmt->execute()) {
                $student_id = $conn->insert_id;
                
                // Insert qualifications
                $qualifiactions_data = array(
                    array('level' => 'Class X', 'board' => $classX_board, 'percentage' => $classX_percentage, 'year' => $classX_year),
                    array('level' => 'Class XII', 'board' => $classXII_board, 'percentage' => $classXII_percentage, 'year' => $classXII_year),
                    array('level' => 'Graduation', 'board' => $graduation_board, 'percentage' => $graduation_percentage, 'year' => $graduation_year),
                    array('level' => 'Masters', 'board' => $masters_board, 'percentage' => $masters_percentage, 'year' => $masters_year)
                );
                
                $qual_stmt = $conn->prepare("INSERT INTO qualifications (student_id, level, board, percentage, passing_year) VALUES (?, ?, ?, ?, ?)");
                
                foreach ($qualifiactions_data as $qual) {
                    if (!empty($qual['board'])) { // Only insert if board is provided
                        $percentage = !empty($qual['percentage']) ? (float)$qual['percentage'] : NULL;
                        $qual_stmt->bind_param("isids", $student_id, $qual['level'], $qual['board'], $percentage, $qual['year']);
                        $qual_stmt->execute();
                    }
                }
                
                $qual_stmt->close();
                
                $_SESSION['student_id'] = $student_id;
                $_SESSION['student_name'] = $firstName . ' ' . $lastName;
                header("Location: home.php");
                exit();
            } else {
                $errors[] = "Error submitting registration: " . $stmt->error;
            }
            
            $stmt->close();
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Student Registration</title>
    <style>
        .error-message {
            color: #d32f2f;
            background-color: #ffebee;
            padding: 10px;
            margin: 10px 0;
            border-radius: 4px;
            border-left: 4px solid #d32f2f;
        }
        .success-message {
            color: #388e3c;
            background-color: #e8f5e9;
            padding: 10px;
            margin: 10px 0;
            border-radius: 4px;
            border-left: 4px solid #388e3c;
        }
        .error-list {
            list-style-position: inside;
        }
    </style>
</head>
<body style="padding-left: 20px; background-color: #eceded;">
    
    <?php if (!empty($errors) && !$success): ?>
        <div class="error-message">
            <strong>Please fix the following errors:</strong>
            <ul class="error-list">
                <?php foreach ($errors as $error): ?>
                    <li><?php echo htmlspecialchars($error); ?></li>
                <?php endforeach; ?>
            </ul>
        </div>
    <?php endif; ?>

    <form action="index.php" method="post">
        <p style="display: flex; justify-content: center; font-size: 20px; font-weight: bold; color: #79a9e0; background-color: aliceblue;">Student Registration Form</p>
        <table>
            <tr>
                <td>FIRST NAME</td><td><input type="text" name="firstName" value="<?php echo htmlspecialchars($_POST['firstName'] ?? ''); ?>"></td>
            </tr>
            <tr>
                <td>LAST NAME</td><td><input type="text" name="lastName" value="<?php echo htmlspecialchars($_POST['lastName'] ?? ''); ?>"></td>
            </tr>
            <tr>
                <td>EMAIL ID</td>
                <td><input type="email" name="email" value="<?php echo htmlspecialchars($_POST['email'] ?? ''); ?>"></td>
            </tr>
            <tr>
                <td>DATE OF BIRTH</td>
                <td>
                    <select name="day">
                        <option value="">Day</option>
                        <?php for($i=1; $i<=31; $i++): ?>
                            <option value="<?php echo $i; ?>" <?php echo (isset($_POST['day']) && $_POST['day'] == $i) ? 'selected' : ''; ?>><?php echo $i; ?></option>
                        <?php endfor; ?>
                    </select>
                    <select name="month">
                        <option value="">Month</option>
                        <option value="1" <?php echo (isset($_POST['month']) && $_POST['month'] == '1') ? 'selected' : ''; ?>>January</option>
                        <option value="2" <?php echo (isset($_POST['month']) && $_POST['month'] == '2') ? 'selected' : ''; ?>>February</option>
                        <option value="3" <?php echo (isset($_POST['month']) && $_POST['month'] == '3') ? 'selected' : ''; ?>>March</option>
                        <option value="4" <?php echo (isset($_POST['month']) && $_POST['month'] == '4') ? 'selected' : ''; ?>>April</option>
                        <option value="5" <?php echo (isset($_POST['month']) && $_POST['month'] == '5') ? 'selected' : ''; ?>>May</option>
                        <option value="6" <?php echo (isset($_POST['month']) && $_POST['month'] == '6') ? 'selected' : ''; ?>>June</option>
                        <option value="7" <?php echo (isset($_POST['month']) && $_POST['month'] == '7') ? 'selected' : ''; ?>>July</option>
                        <option value="8" <?php echo (isset($_POST['month']) && $_POST['month'] == '8') ? 'selected' : ''; ?>>August</option>
                        <option value="9" <?php echo (isset($_POST['month']) && $_POST['month'] == '9') ? 'selected' : ''; ?>>September</option>
                        <option value="10" <?php echo (isset($_POST['month']) && $_POST['month'] == '10') ? 'selected' : ''; ?>>October</option>
                        <option value="11" <?php echo (isset($_POST['month']) && $_POST['month'] == '11') ? 'selected' : ''; ?>>November</option>
                        <option value="12" <?php echo (isset($_POST['month']) && $_POST['month'] == '12') ? 'selected' : ''; ?>>December</option>
                    </select>
                    <select name="year">
                        <option value="">Year</option>
                        <?php for($i=2026; $i>=2000; $i--): ?>
                            <option value="<?php echo $i; ?>" <?php echo (isset($_POST['year']) && $_POST['year'] == $i) ? 'selected' : ''; ?>><?php echo $i; ?></option>
                        <?php endfor; ?>
                    </select>
                </td>
            </tr>
            <tr>
                <td>MOBILE NUMBER</td>
                <td><input type="tel" name="mobileNumber" value="<?php echo htmlspecialchars($_POST['mobileNumber'] ?? ''); ?>"></td>
            </tr>
            <tr>
                <td>GENDER</td>
                <td>
                    <label for="Male">Male</label><input type="radio" id="Male" name="gender" value="Male" <?php echo (isset($_POST['gender']) && $_POST['gender'] == 'Male') ? 'checked' : ''; ?>>
                    <label for="Female">Female</label><input type="radio" id="Female" name="gender" value="Female" <?php echo (isset($_POST['gender']) && $_POST['gender'] == 'Female') ? 'checked' : ''; ?>>
                </td>
            </tr>
            <tr>
                <td>ADDRESS</td>
                <td><textarea name="comment"><?php echo htmlspecialchars($_POST['comment'] ?? ''); ?></textarea></td>
            </tr>
            <tr>
                <td>CITY</td>
                <td><input type="text" name="City" value="<?php echo htmlspecialchars($_POST['City'] ?? ''); ?>"></td>
            </tr>
            <tr>
                <td>PIN CODE</td>
                <td><input type="text" name="pinCode" value="<?php echo htmlspecialchars($_POST['pinCode'] ?? ''); ?>"></td>
            </tr>
            <tr>
                <td>STATE</td>
                <td><input type="text" name="state" value="<?php echo htmlspecialchars($_POST['state'] ?? ''); ?>"></td>
            </tr>
            <tr>
                <td>COUNTRY</td>
                <td><input type="text" name="country" value="<?php echo htmlspecialchars($_POST['country'] ?? ''); ?>"></td>
            </tr>
            <tr>
                <td>HOBBIES</td>
                <td>
                    <label for="Drawing">Drawing</label><input type="radio" name="hobbies" id="Drawing" value="Drawing" <?php echo (isset($_POST['hobbies']) && $_POST['hobbies'] == 'Drawing') ? 'checked' : ''; ?>>
                    <label for="Dancing">Dancing</label><input type="radio" name="hobbies" id="Dancing" value="Dancing" <?php echo (isset($_POST['hobbies']) && $_POST['hobbies'] == 'Dancing') ? 'checked' : ''; ?>>
                    <label for="Singing">Singing</label><input type="radio" name="hobbies" id="Singing" value="Singing" <?php echo (isset($_POST['hobbies']) && $_POST['hobbies'] == 'Singing') ? 'checked' : ''; ?>>
                    <label for="Sketching">Sketching</label><input type="radio" name="hobbies" id="Sketching" value="Sketching" <?php echo (isset($_POST['hobbies']) && $_POST['hobbies'] == 'Sketching') ? 'checked' : ''; ?>>
                    <label for="other">Other</label><input type="text" name="otherhobbies" id="other" value="<?php echo htmlspecialchars($_POST['otherhobbies'] ?? ''); ?>">
                </td>
            </tr>
        </table>

        <table>
            <tr>
                <td>QUALIFICATION</td><td>S1.No</td>
                <td>Examination</td>
                <td>BOARD</td>
                <td>PERCENTAGE</td>
                <td>YEAR OF PASSING</td>
            </tr>
            <tr>
                <td></td>
                <td>1</td>
                <td>Class X</td>
                <td><input type="text" name="class1" value="<?php echo htmlspecialchars($_POST['class1'] ?? ''); ?>"></td>
                <td><input type="number" name="percentage1" value="<?php echo htmlspecialchars($_POST['percentage1'] ?? ''); ?>"></td>
                <td><input type="text" name="year1" value="<?php echo htmlspecialchars($_POST['year1'] ?? ''); ?>"></td>
            </tr>
            <tr>
                <td></td>
                <td>2</td>
                <td>Class XII</td>
                <td><input type="text" name="class2" value="<?php echo htmlspecialchars($_POST['class2'] ?? ''); ?>"></td>
                <td><input type="number" name="percentage2" value="<?php echo htmlspecialchars($_POST['percentage2'] ?? ''); ?>"></td>
                <td><input type="text" name="year2" value="<?php echo htmlspecialchars($_POST['year2'] ?? ''); ?>"></td>
            </tr>
            <tr>
                <td></td>
                <td>3</td>
                <td>Graduation</td>
                <td><input type="text" name="class3" value="<?php echo htmlspecialchars($_POST['class3'] ?? ''); ?>"></td>
                <td><input type="number" name="percentage3" value="<?php echo htmlspecialchars($_POST['percentage3'] ?? ''); ?>"></td>
                <td><input type="text" name="year3" value="<?php echo htmlspecialchars($_POST['year3'] ?? ''); ?>"></td>
            </tr>
            <tr>
                <td></td>
                <td>4</td>
                <td>Masters</td>
                <td><input type="text" name="mastersBoard" value="<?php echo htmlspecialchars($_POST['mastersBoard'] ?? ''); ?>"></td>
                <td><input type="number" name="mastersPercentage" value="<?php echo htmlspecialchars($_POST['mastersPercentage'] ?? ''); ?>"></td>
                <td><input type="text" name="mastersYear" value="<?php echo htmlspecialchars($_POST['mastersYear'] ?? ''); ?>"></td>
            </tr>
        </table>
        <br><br>

        <table>
            <tr>
                <td>Courses Applied For</td>
                <td>
                    <label for="BCA">BCA</label><input type="checkbox" id="BCA" name="bca" value="BCA" <?php echo (isset($_POST['bca']) && $_POST['bca'] == 'BCA') ? 'checked' : ''; ?>>
                    <label for="B.Com">B.Com</label><input type="checkbox" id="B.Com" name="bcom" value="B.Com" <?php echo (isset($_POST['bcom']) && $_POST['bcom'] == 'B.Com') ? 'checked' : ''; ?>>
                    <label for="B.Sc">B.Sc</label><input type="checkbox" id="B.Sc" name="bsc" value="B.Sc" <?php echo (isset($_POST['bsc']) && $_POST['bsc'] == 'B.Sc') ? 'checked' : ''; ?>>
                    <label for="B.A">B.A</label><input type="checkbox" id="B.A" name="ba" value="B.A" <?php echo (isset($_POST['ba']) && $_POST['ba'] == 'B.A') ? 'checked' : ''; ?>>
                </td>
            </tr>
            <tr>
                <td colspan="2" style="text-align: center; padding-top: 20px;">
                    <input type="submit" value="Submit" name="submit">
                    <input type="reset" value="Reset" name="reset">
                </td>
            </tr>
        </table>
    </form>
</body>
</html>
