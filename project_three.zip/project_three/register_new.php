<?php
session_start();
include "connect.php";

$errors = [];
$success = false;

if (isset($_POST['register'])) {

    $fullname = sanitize($_POST['fullname']);
    $email = sanitize($_POST['email']);
    $phone = sanitize($_POST['phone']);
    $password = $_POST['password'];
    $confirm_password = $_POST['confirm_password'];

    // Validation
    if (empty($fullname) || empty($email) || empty($password)) {
        $errors[] = "All required fields must be filled!";
    }

    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $errors[] = "Invalid email format!";
    }

    if (strlen($password) < 6) {
        $errors[] = "Password must be at least 6 characters!";
    }

    if ($password !== $confirm_password) {
        $errors[] = "Passwords do not match!";
    }

    if (count($errors) == 0) {
        // Check if email already exists
        $check_query = "SELECT email FROM users WHERE email = ?";
        $check_result = executeQuery($check_query, [$email]);

        if ($check_result['success'] && $check_result['result']->num_rows > 0) {
            $errors[] = "Email already registered!";
        } else {
            // Hash password using bcrypt
            $hashed_password = password_hash($password, PASSWORD_BCRYPT);

            // Insert new user
            $insert_query = "INSERT INTO users (fullname, email, phone, password) VALUES (?, ?, ?, ?)";
            $result = executeQuery($insert_query, [$fullname, $email, $phone, $hashed_password]);

            if ($result['success']) {
                $success = true;
                // Auto-login after registration
                $_SESSION['user_id'] = $conn->insert_id;
                $_SESSION['email'] = $email;
                $_SESSION['fullname'] = $fullname;
                
                header("Location: dashboard.php");
                exit();
            } else {
                $errors[] = "Registration failed! " . $result['error'];
            }
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Register | NE Hotel</title>
    <link rel="stylesheet" href="css/style.css">
    <style>
        body {
            font-family: Arial, sans-serif;
            background: #f0f0f0;
            margin: 0;
        }
        .container {
            max-width: 500px;
            margin: 50px auto;
            padding: 20px;
            background: white;
            border-radius: 10px;
            box-shadow: 0 0 20px rgba(0,0,0,0.1);
        }
        .form-box {
            text-align: center;
        }
        h2 {
            color: #8b6f47;
            margin-bottom: 30px;
        }
        .error {
            background: #f8d7da;
            color: #721c24;
            padding: 15px;
            border-radius: 5px;
            margin-bottom: 20px;
            border: 1px solid #f5c6cb;
        }
        .error p {
            margin: 5px 0;
        }
        form {
            display: flex;
            flex-direction: column;
        }
        input {
            padding: 12px;
            margin: 10px 0;
            border: 1px solid #ddd;
            border-radius: 5px;
            font-size: 14px;
            font-family: Arial;
        }
        input:focus {
            outline: none;
            border-color: #8b6f47;
            box-shadow: 0 0 5px rgba(139, 111, 71, 0.3);
        }
        button {
            padding: 12px;
            margin: 15px 0;
            background: #8b6f47;
            color: white;
            border: none;
            border-radius: 5px;
            font-size: 16px;
            cursor: pointer;
            font-weight: bold;
        }
        button:hover {
            background: #162e6e;
        }
        .link {
            text-align: center;
            margin-top: 15px;
        }
        .link a {
            color: #8b6f47;
            text-decoration: none;
        }
        .link a:hover {
            text-decoration: underline;
        }
    </style>
</head>
<body>

    <div class="container">
        <div class="form-box">
            <h2>🏨 Create Account</h2>

            <?php if (count($errors) > 0): ?>
                <div class="error">
                    <?php foreach ($errors as $error): ?>
                        <p>❌ <?php echo $error; ?></p>
                    <?php endforeach; ?>
                </div>
            <?php endif; ?>

            <form method="POST">
                <input type="text" name="fullname" placeholder="Full Name" required>
                <input type="email" name="email" placeholder="Email" required>
                <input type="tel" name="phone" placeholder="Phone Number">
                <input type="password" name="password" placeholder="Password (min 6 chars)" required>
                <input type="password" name="confirm_password" placeholder="Confirm Password" required>
                <button type="submit" name="register">Create Account</button>
            </form>

            <div class="link">
                <p>Already have an account? <a href="login.php">Login Here</a></p>
            </div>
        </div>
    </div>

</body>
</html>
