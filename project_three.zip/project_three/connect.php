<?php
// connect.php - Fixed version
$host = 'localhost';
$user = 'root'; // Change to your username
$password = ''; // Change to your password (usually empty for WAMP)
$database = 'hotel_db'; // Change to your database name

// Add these options to handle authentication
$conn = new mysqli($host, $user, $password, $database);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Set charset to utf8mb4
$conn->set_charset("utf8mb4");

function sanitize($data)
{
    global $conn;
    return htmlspecialchars(strip_tags(trim($data)));
}

function executeQuery($sql, $params = [])
{
    global $conn;

    $stmt = $conn->prepare($sql);
    if (!$stmt) {
        return ['success' => false, 'error' => $conn->error];
    }

    if (!empty($params)) {
        $types = str_repeat('s', count($params));
        $stmt->bind_param($types, ...$params);
    }

    $execution = $stmt->execute();
    if (!$execution) {
        return ['success' => false, 'error' => $stmt->error];
    }

    $sqlType = strtoupper(strtok(trim($sql), " "));
    if ($sqlType === 'SELECT' || $sqlType === 'SHOW' || $sqlType === 'DESCRIBE' || $sqlType === 'EXPLAIN') {
        $result = $stmt->get_result();
        if ($result === false) {
            return ['success' => false, 'error' => $stmt->error];
        }
        return ['success' => true, 'result' => $result, 'stmt' => $stmt];
    }

    return ['success' => true, 'affected_rows' => $stmt->affected_rows, 'insert_id' => $stmt->insert_id, 'stmt' => $stmt];
}

