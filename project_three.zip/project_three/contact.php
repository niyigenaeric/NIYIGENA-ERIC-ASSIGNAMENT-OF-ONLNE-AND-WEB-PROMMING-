<?php
// Contact form handler with database storage
$messageSent = false;
$errorMessage = '';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $name = trim($_POST['name']);
    $email = trim($_POST['email']);
    $phone = trim($_POST['phone'] ?? '');
    $location = trim($_POST['location'] ?? '');
    $subject = trim($_POST['subject']);
    $message = trim($_POST['message']);

    // Basic validation
    if (empty($name) || empty($email) || empty($subject) || empty($message)) {
        $errorMessage = 'Please fill in all required fields.';
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $errorMessage = 'Please enter a valid email address.';
    } else {
        // Include database connection
        include 'connect.php';

        // Prepare the insert query
        $sql = "INSERT INTO contact (fullname, email, phone, location, message) VALUES (?, ?, ?, ?, ?)";
        $params = [$name, $email, $phone, $location, $message];

        $result = executeQuery($sql, $params);

        if ($result['success']) {
            $messageSent = true;
        } else {
            $errorMessage = 'Failed to send message. Please try again.';
        }
    }
}

$page_title = "Contact Us";
include "includes/header.php";
?>

<style>
body {
    padding-top: 90px;
}
.container{
    width:80%;
    margin:auto;
    padding:40px 0;
}

.contact-info{
    margin-bottom:30px;
}

form input, form textarea{
    width:100%;
    padding:10px;
    margin-bottom:15px;
    border:1px solid #ccc;
    border-radius:5px;
}

form button{
    padding:10px 20px;
    background:#333;
    color:#fff;
    border:none;
    cursor:pointer;
    border-radius:5px;
}

.success{
    background:#e0ffe0;
    padding:10px;
    margin-bottom:15px;
    border:1px solid #b2ffb2;
}
</style>

</head>

<body>

<!-- NAVBAR -->
<div class="navbar">
    <div class="logo">
        <h2>NE Hotel</h2>
    </div>

    <div class="menu">
        <a href="dashboard.php">Home</a>
        <a href="about.php">About Us</a>
        <a href="menu.php">Menu</a>
        <a href="order.php">Order</a>
        <a href="gallery.php">Gallery</a>
        <a href="contact.php">Contact</a>
    </div>

    <div class="auth">
        <?php if (isset($_SESSION['fullname'])): ?>
            <span style="color:white;">Hello, <?php echo explode(' ', $_SESSION['fullname'])[0]; ?></span>
            <a href="logout.php">Logout</a>
        <?php else: ?>
            <a href="login.php">Login</a>
        <?php endif; ?>
    </div>
</div>

<div class="container">

<!-- CONTACT INFO -->
<section class="contact-info">

    <h2>Contact NE Hotel</h2>

    <p><b>Email:</b> info@nehotel.com</p>
    <p><b>Phone:</b> +250 780 581 260</p>
    <p><b>Location:</b> Kigali, Rwanda</p>
    <p><b>Working Hours:</b> 24/7 Service Available</p>

</section>

<!-- SUCCESS MESSAGE -->
<?php if ($messageSent): ?>
    <div class="success">
        ✅ Thank you <?= htmlspecialchars($name) ?>, your message has been sent successfully!
    </div>
<?php endif; ?>

<!-- ERROR MESSAGE -->
<?php if ($errorMessage): ?>
    <div style="background:#ffe0e0; padding:10px; margin-bottom:15px; border:1px solid #ffb2b2; color:#d00;">
        ❌ <?= htmlspecialchars($errorMessage) ?>
    </div>
<?php endif; ?>

<!-- CONTACT FORM -->
<section>

    <h3>Send Us a Message</h3>

    <form method="POST">

        <input type="text" name="name" placeholder="Your Full Name" required value="<?= htmlspecialchars($_POST['name'] ?? '') ?>">

        <input type="email" name="email" placeholder="Your Email" required value="<?= htmlspecialchars($_POST['email'] ?? '') ?>">

        <input type="tel" name="phone" placeholder="Your Phone Number (optional)" value="<?= htmlspecialchars($_POST['phone'] ?? '') ?>">

        <input type="text" name="location" placeholder="Your Location (optional)" value="<?= htmlspecialchars($_POST['location'] ?? '') ?>">

        <input type="text" name="subject" placeholder="Subject" required value="<?= htmlspecialchars($_POST['subject'] ?? '') ?>">

        <textarea name="message" rows="6" placeholder="Your Message" required><?= htmlspecialchars($_POST['message'] ?? '') ?></textarea>

        <button type="submit">Send Message</button>

    </form>

</section>

<!-- EXTRA INFO -->
<section style="margin-top:40px;">

    <h3>Why Contact NE Hotel?</h3>

    <p>
        We are always ready to assist you with room booking, restaurant orders,
        event reservations, and general inquiries.
    </p>

    <p>
        Our support team responds quickly to ensure you get the best experience
        at NE Hotel.
    </p>

</section>

</div>

<?php include "includes/footer.php"; ?>