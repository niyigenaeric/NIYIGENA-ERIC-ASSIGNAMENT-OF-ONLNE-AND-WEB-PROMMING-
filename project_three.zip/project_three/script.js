document.addEventListener('DOMContentLoaded', () => {
    const authInputs = document.querySelectorAll('.auth-input');
    const forms = document.querySelectorAll('.auth-card form');

    authInputs.forEach(input => {
        if (input.value.trim()) {
            input.parentElement.classList.add('focused');
        }

        input.addEventListener('focus', () => {
            input.parentElement.classList.add('focused');
        });

        input.addEventListener('blur', () => {
            if (!input.value.trim()) {
                input.parentElement.classList.remove('focused');
            }
        });
    });

    const validateEmail = value => /^\S+@\S+\.\S+$/.test(value);

    const showErrors = (form, messages) => {
        let errorBox = form.querySelector('.error');

        if (!errorBox) {
            errorBox = document.createElement('div');
            errorBox.className = 'error';
            form.parentElement.insertBefore(errorBox, form);
        }

        errorBox.innerHTML = messages.map(msg => `<p>${msg}</p>`).join('');
    };

    forms.forEach(form => {
        form.addEventListener('submit', e => {
            const fields = Array.from(form.querySelectorAll('.auth-input'));
            const messages = [];
            const emailField = form.querySelector('[name=email]');
            const passwordField = form.querySelector('[name=password]');
            const confirmField = form.querySelector('[name=confirm_password]');
            const fullnameField = form.querySelector('[name=fullname]');

            fields.forEach(input => {
                if (input.hasAttribute('required') && !input.value.trim()) {
                    messages.push(`${input.previousElementSibling.textContent.replace('*', '')} is required.`);
                }
            });

            if (emailField && emailField.value.trim() && !validateEmail(emailField.value.trim())) {
                messages.push('Please enter a valid email address.');
            }

            if (passwordField && passwordField.value.trim() && passwordField.value.trim().length < 6) {
                messages.push('Password must be at least 6 characters long.');
            }

            if (confirmField && passwordField && passwordField.value.trim() !== confirmField.value.trim()) {
                messages.push('Passwords do not match.');
            }

            if (messages.length > 0) {
                e.preventDefault();
                form.classList.add('shake');
                window.requestAnimationFrame(() => {
                    setTimeout(() => form.classList.remove('shake'), 320);
                });
                showErrors(form, messages);
            }
        });
    });
});
