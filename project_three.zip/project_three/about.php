﻿<?php
session_start();
$page_title = "About Us";
include "includes/header.php";
?>

    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Inter', system-ui, -apple-system, 'Segoe UI', Roboto, Helvetica, sans-serif;
            background: #ffffff !important;
            color: #1a2e2a;
        }

        .container {
            max-width: 1200px;
            margin: 0 auto;
            padding: 2rem 2rem 4rem;
            background: #ffffff;
        }

        h1,
        h2,
        h3 {
            margin-bottom: 1rem;
        }

        section {
            margin-bottom: 3rem;
        }

        .hero-section {
            text-align: center;
            margin-bottom: 3rem;
            padding: 2rem;
            background: linear-gradient(135deg, #f8f9fa 0%, #ffffff 100%);
            border-radius: 2rem;
        }

        .hero-section h1 {
            font-size: 2.5rem;
            color: #1e4a44;
            margin-bottom: 1rem;
        }

        .hero-section p {
            font-size: 1.1rem;
            color: #5e6f6b;
            max-width: 700px;
            margin: 0 auto;
        }

        .section-title {
            font-size: 1.8rem;
            color: #1e4a44;
            margin-bottom: 1.5rem;
            border-left: 4px solid #e9c46a;
            padding-left: 1rem;
        }

        .timeline-item,
        .value-item {
            padding: 1.2rem;
            background: #f9faf9;
            border-radius: 1rem;
            transition: all 0.3s ease;
        }

        .timeline-item:hover,
        .value-item:hover {
            transform: translateY(-4px);
            box-shadow: 0 8px 20px rgba(0, 0, 0, 0.08);
        }

        .timeline-item h3,
        .value-item p {
            color: #1e4a44;
            margin-bottom: 0.5rem;
        }

        .timeline-item p,
        .hero-section p,
        .value-item p,
        section p {
            line-height: 1.75;
            color: #5f6c6a;
        }

        .values-list {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
            gap: 1rem;
            margin-top: 1rem;
        }

        @media (max-width: 900px) {
            .container {
                padding: 1.5rem;
            }

            .hero-section h1 {
                font-size: 2rem;
            }
        }

        @media (max-width: 600px) {
            .hero-section {
                padding: 1.5rem;
            }

            .section-title {
                font-size: 1.6rem;
            }
        }
    </style>

    <div class="container">

        <div class="hero-section">
            <h1>About NE Hotel</h1>
            <p>Discover our story, mission, and the values that make us a trusted hospitality destination.</p>
        </div>

        <section>
            <h2 class="section-title">Our Story</h2>
            <p>Founded in 2015, NE Hotel has been serving distinguished guests with exceptional cuisine and world-class hospitality for over a decade.</p>
            <p>What began as a small family-owned restaurant has grown into one of the region's most respected hospitality destinations.</p>
            <p>Our commitment to excellence is reflected in every detail — from carefully selected ingredients to professional service and a warm, elegant atmosphere.</p>
        </section>

        <section>
            <h2 class="section-title">Our Mission</h2>
            <p>To deliver outstanding dining and hospitality experiences by combining culinary excellence with warm, personalized service in a comfortable environment.</p>
        </section>

        <section>
            <h2 class="section-title">Our Vision</h2>
            <p>To be recognized as a leading hotel and restaurant destination known for quality, innovation, and unforgettable guest experiences.</p>
        </section>

        <section>
            <h2 class="section-title">Our Journey</h2>

            <div class="timeline-item">
                <h3>📅 2015 - The Beginning</h3>
                <p>NE Hotel started as a small restaurant with 50 seats focusing on quality food and service.</p>
            </div>

            <div class="timeline-item">
                <h3>📅 2018 - Expansion</h3>
                <p>The business expanded into hotel services and increased capacity for guests.</p>
            </div>

            <div class="timeline-item">
                <h3>📅 2020 - Recognition</h3>
                <p>NE Hotel became recognized for excellent hospitality and customer satisfaction.</p>
            </div>

            <div class="timeline-item">
                <h3>📅 2025 - Digital Era</h3>
                <p>We introduced online booking and modern service systems.</p>
            </div>

            <div class="timeline-item">
                <h3>📅 2026 - Today</h3>
                <p>NE Hotel continues to grow as a trusted hospitality brand in Kigali.</p>
            </div>
        </section>

        <section>
            <h2 class="section-title">Our Team</h2>
            <p>👨‍🍳 Our chefs bring international experience and passion to every dish they prepare.</p>
            <p>🛎️ Our service team ensures every guest receives professional and friendly attention.</p>
            <p>🧹 Our support staff maintains cleanliness, comfort, and high service standards.</p>
        </section>

        <section>
            <h2 class="section-title">Our Values</h2>
            <div class="values-list">
                <div class="value-item"><p>⭐ Premium Quality</p></div>
                <div class="value-item"><p>👨‍💼 Expert Staff</p></div>
                <div class="value-item"><p>🌿 Elegant Environment</p></div>
                <div class="value-item"><p>💡 Innovation</p></div>
                <div class="value-item"><p>❤️ Guest Focus</p></div>
                <div class="value-item"><p>🏆 Excellence</p></div>
            </div>
        </section>

    </div>

<?php include "includes/footer.php"; ?>
