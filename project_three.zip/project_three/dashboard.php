<?php
session_start();

$page_title = "Dashboard";
$user = isset($_SESSION['email']) ? explode('@', $_SESSION['email'])[0] : null;

include "includes/header.php";
?>

<!-- SLIDER SECTION -->
<div class="slider">
    <img id="slide" src="images/image1.avif" alt="Hotel Slider">
    <div class="slider-text">
        <h1>Welcome <?php echo htmlspecialchars($user); ?> 👋</h1>
        <p>Explore our hotel services: Rooms, Food, Drinks, Fruits & Seminar Halls.</p>
    </div>
</div>

<!-- SERVICES SECTION -->
<div class="container">
    <div class="form-box">
        <h2>Hotel Services</h2>
        <p>Choose what you want to explore or book.</p>
        <div class="services">
            <div class="card">
                <h3>🏨 Rooms</h3>
                <p>Luxury single, double, VIP rooms</p>
                <a href="room.php" class="btn">Book Now</a>
            </div>
            <div class="card">
                <h3>🍽️ Food</h3>
                <p>Fresh meals & drinks</p>
                <a href="menu.php" class="btn">View Menu</a>
            </div>
            <div class="card">
                <h3>🏢 Seminar</h3>
                <p>Meetings & conferences</p>
                <a href="room.php" class="btn">Reserve Hall</a>
            </div>
            <div class="card">
                <h3>📸 Gallery</h3>
                <p>Hotel images & facilities</p>
                <a href="gallery.php" class="btn">View Gallery</a>
            </div>
        </div>
    </div>
</div>

<style>
.slider {
    width: 100%;
    height: 500px;
    position: relative;
    overflow: hidden;
}

.slider img {
    width: 100%;
    height: 100%;
    object-fit: cover;
}

.slider-text {
    position: absolute;
    top: 50%;
    left: 50%;
    transform: translate(-50%, -50%);
    color: white;
    background: rgba(0, 0, 0, 0.5);
    padding: 20px 30px;
    border-radius: 10px;
    text-align: center;
}

.container {
    max-width: 1200px;
    margin: 0 auto;
    padding: 40px 20px;
}

.form-box {
    text-align: center;
}

.services {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
    gap: 30px;
    margin-top: 30px;
}

.card {
    background: #f8f9fa;
    padding: 25px;
    border-radius: 10px;
    border-bottom: 4px solid #8b6f47;
    transition: transform 0.3s;
}

.card:hover {
    transform: translateY(-5px);
}

.card h3 {
    color: #8b6f47;
    margin-bottom: 10px;
}

.btn {
    display: inline-block;
    margin-top: 15px;
    padding: 8px 20px;
    background: #8b6f47;
    color: white;
    text-decoration: none;
    border-radius: 5px;
    transition: background 0.3s;
}

.btn:hover {
    background: #6b5335;
}

@media (max-width: 768px) {
    .slider {
        height: 300px;
    }
    
    .slider-text h1 {
        font-size: 1.5rem;
    }
    
    .services {
        gap: 20px;
    }
}
</style>

<script>
let images = ["images/image1.avif", "images/image2.jpg", "images/image3.avif"];
let i = 0;

function slideShow() {
    const slideImg = document.getElementById("slide");
    if (slideImg) {
        slideImg.src = images[i];
        i = (i + 1) % images.length;
        setTimeout(slideShow, 4000);
    }
}

window.onload = slideShow;
</script>

<?php include "includes/footer.php"; ?>