<?php
include "session_config.php";
include "connect.php";

if (isset($_SESSION['user_id'])) {
    header("Location: dashboard.php");
    exit();
}

$errors = [];
$success = false;

// Initialize all variables
$fullname_value = '';
$email_value = '';
$phone_value = '';

if (isset($_POST['register'])) {
    $fullname_value = sanitize($_POST['fullname']);
    $email_value = sanitize($_POST['email']);
    $phone_value = sanitize($_POST['phone']);
    $password = $_POST['password'];
    $confirm_password = $_POST['confirm_password'];

    // Validation
    if (empty($fullname_value) || empty($email_value) || empty($password)) {
        $errors[] = "All required fields must be filled!";
    }

    if (!filter_var($email_value, FILTER_VALIDATE_EMAIL)) {
        $errors[] = "Invalid email format!";
    }

    if (strlen($password) < 6) {
        $errors[] = "Password must be at least 6 characters!";
    }

    if ($password !== $confirm_password) {
        $errors[] = "Passwords do not match!";
    }

    if (count($errors) == 0) {
        // Check if email already exists
        $check_query = "SELECT email FROM users WHERE email = ?";
        $check_result = executeQuery($check_query, [$email_value]);

        if ($check_result['success'] && $check_result['result']->num_rows > 0) {
            $errors[] = "Email already registered!";
        } else {
            // Hash password using bcrypt
            $hashed_password = password_hash($password, PASSWORD_DEFAULT);

            // Insert new user
            $insert_query = "INSERT INTO users (fullname, email, phone, password) VALUES (?, ?, ?, ?)";
            $result = executeQuery($insert_query, [$fullname_value, $email_value, $phone_value, $hashed_password]);

            if ($result['success']) {
                $_SESSION['user_id'] = mysqli_insert_id($conn);
                $_SESSION['email'] = $email_value;
                $_SESSION['fullname'] = $fullname_value;
                $success = true;

                // Redirect after 2 seconds with JavaScript
                echo '<!DOCTYPE html>
                <html>
                <head>
                    <meta charset="UTF-8">
                    <meta http-equiv="refresh" content="2;url=dashboard.php">
                    <title>Registration Successful</title>
                    <style>
                        * {
                            margin: 0;
                            padding: 0;
                            box-sizing: border-box;
                        }
                        body {
                            font-family: "Inter", system-ui, -apple-system, "Segoe UI", Roboto, Helvetica, sans-serif;
                            background: linear-gradient(135deg, #f5ede3 0%, #e8dcc8 100%);
                            min-height: 100vh;
                            display: flex;
                            align-items: center;
                            justify-content: center;
                            padding: 2rem;
                        }
                        .success-container {
                            max-width: 500px;
                            width: 100%;
                            background: white;
                            border-radius: 2rem;
                            padding: 3rem 2rem;
                            text-align: center;
                            box-shadow: 0 25px 50px -12px rgba(0, 0, 0, 0.25);
                            animation: fadeIn 0.5s ease;
                        }
                        @keyframes fadeIn {
                            from { opacity: 0; transform: translateY(-20px); }
                            to { opacity: 1; transform: translateY(0); }
                        }
                        .success-icon {
                            width: 80px;
                            height: 80px;
                            background: #1e4a44;
                            color: white;
                            font-size: 3rem;
                            border-radius: 50%;
                            display: flex;
                            align-items: center;
                            justify-content: center;
                            margin: 0 auto 1.5rem;
                            animation: scaleIn 0.5s ease 0.2s both;
                        }
                        @keyframes scaleIn {
                            from { transform: scale(0); }
                            to { transform: scale(1); }
                        }
                        h2 {
                            color: #1e2f2c;
                            font-size: 1.8rem;
                            margin-bottom: 1rem;
                        }
                        p {
                            color: #5f6c6a;
                            margin-bottom: 1rem;
                            line-height: 1.5;
                        }
                        .welcome-name {
                            color: #b87c3a;
                            font-weight: 600;
                        }
                        .redirect-message {
                            margin-top: 1.5rem;
                            padding-top: 1rem;
                            border-top: 1px solid #e2e8f0;
                            font-size: 0.85rem;
                            color: #8ba19e;
                        }
                        .spinner {
                            display: inline-block;
                            width: 16px;
                            height: 16px;
                            border: 2px solid #e2e8f0;
                            border-top-color: #1e4a44;
                            border-radius: 50%;
                            animation: spin 0.8s linear infinite;
                            margin-left: 8px;
                            vertical-align: middle;
                        }
                        @keyframes spin {
                            to { transform: rotate(360deg); }
                        }
                    </style>
                </head>
                <body>
                    <div class="success-container">
                        <div class="success-icon">✓</div>
                        <h2>Welcome to NE Hotel! 🎉</h2>
                        <p>You have successfully created an account on <strong>NE Hotel</strong>.</p>
                        <p>Hello, <span class="welcome-name">' . htmlspecialchars($fullname_value) . '</span>!</p>
                        <p>Redirecting you to your dashboard <span class="spinner"></span></p>
                        <div class="redirect-message">
                            If you are not redirected automatically, <a href="dashboard.php" style="color: #b87c3a;">click here</a>
                        </div>
                    </div>
                </body>
                </html>';
                exit();
            } else {
                $errors[] = "Registration failed. Please try again later.";
            }
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, viewport-fit=cover">
    <title>NE Hotel | Register</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Inter', system-ui, -apple-system, 'Segoe UI', Roboto, Helvetica, sans-serif;
            background: linear-gradient(135deg, #f5ede3 0%, #e8dcc8 100%);
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 2rem;
        }

        .auth-page {
            width: 100%;
            max-width: 1400px;
            margin: 0 auto;
        }

        .auth-panel {
            display: flex;
            flex-wrap: wrap;
            background: rgba(255, 255, 255, 0.96);
            border-radius: 2.5rem;
            box-shadow: 0 25px 50px -12px rgba(0, 0, 0, 0.25);
            overflow: hidden;
        }

        .auth-side {
            flex: 1.1;
            background: linear-gradient(125deg, #0b2b26 0%, #1a4a42 100%);
            padding: 3rem 2.5rem;
            display: flex;
            flex-direction: column;
            justify-content: center;
            color: white;
            position: relative;
        }

        .auth-side::before {
            content: '';
            position: absolute;
            top: -30%;
            right: -20%;
            width: 280px;
            height: 280px;
            background: radial-gradient(circle, rgba(255, 215, 150, 0.18) 0%, rgba(255, 215, 150, 0) 70%);
            border-radius: 50%;
            pointer-events: none;
        }

        .brand-mark {
            font-size: 2.2rem;
            font-weight: 700;
            background: rgba(255, 255, 240, 0.2);
            display: inline-block;
            width: fit-content;
            padding: 0.4rem 1.2rem;
            border-radius: 60px;
            backdrop-filter: blur(4px);
            margin-bottom: 2rem;
            border: 1px solid rgba(255, 255, 210, 0.3);
        }

        .side-top h3 {
            font-size: 2rem;
            font-weight: 600;
            margin: 1rem 0 0.75rem 0;
        }

        .side-top p {
            font-size: 1rem;
            opacity: 0.85;
            max-width: 85%;
            line-height: 1.5;
        }

        .auth-card {
            flex: 1.2;
            padding: 3rem 2.8rem;
            background: #ffffff;
        }

        .auth-card h2 {
            font-size: 2rem;
            font-weight: 700;
            color: #1e2f2c;
            margin-bottom: 0.6rem;
        }

        .auth-card>p {
            color: #5f6c6a;
            margin-bottom: 1.8rem;
            font-size: 0.9rem;
            border-left: 3px solid #d4af7a;
            padding-left: 0.9rem;
        }

        .error {
            background: #fff5f5;
            border-left: 4px solid #e07c7c;
            padding: 0.9rem 1.2rem;
            border-radius: 1rem;
            margin-bottom: 1.8rem;
            color: #b13e3e;
            font-size: 0.85rem;
        }

        .error p {
            margin: 0.2rem 0;
        }

        .input-group {
            position: relative;
            margin-bottom: 1.8rem;
        }

        .auth-input {
            width: 100%;
            padding: 1rem 1rem 0.5rem 1rem;
            font-size: 1rem;
            border: 1.5px solid #e2e8f0;
            background: #ffffff;
            border-radius: 1rem;
            outline: none;
            transition: all 0.2s ease;
            font-family: inherit;
            color: #1a2e2a;
        }

        .auth-input:focus {
            border-color: #c9a96e;
            box-shadow: 0 0 0 3px rgba(201, 169, 110, 0.2);
        }

        .auth-input.error-field {
            border-color: #e07c7c;
            background-color: #fffafa;
        }

        .input-label {
            position: absolute;
            left: 1rem;
            top: 0.9rem;
            background-color: transparent;
            padding: 0 0.2rem;
            color: #7e8b88;
            font-size: 1rem;
            transition: 0.2s ease;
            pointer-events: none;
        }

        .auth-input:focus~.input-label,
        .auth-input:not(:placeholder-shown)~.input-label {
            top: -0.55rem;
            left: 0.8rem;
            font-size: 0.75rem;
            background: white;
            color: #b98f52;
            font-weight: 500;
            padding: 0 0.3rem;
        }

        .auth-input:placeholder-shown~.input-label {
            top: 0.9rem;
            font-size: 1rem;
        }

        .field-error {
            font-size: 0.7rem;
            color: #d14545;
            margin-top: 0.3rem;
            margin-left: 0.5rem;
            display: none;
        }

        .input-group.has-error .field-error {
            display: block;
        }

        .input-group.has-error .auth-input {
            border-color: #e07c7c;
        }

        .password-strength {
            margin-top: 0.3rem;
            font-size: 0.7rem;
        }

        .strength-weak {
            color: #e07c7c;
        }

        .strength-medium {
            color: #e9c46a;
        }

        .strength-strong {
            color: #2e7d64;
        }

        .auth-button {
            width: 100%;
            background: #1e4a44;
            color: white;
            font-size: 1rem;
            font-weight: 600;
            padding: 0.9rem;
            border: none;
            border-radius: 2rem;
            cursor: pointer;
            transition: all 0.25s;
            margin-top: 0.6rem;
        }

        .auth-button:hover {
            background: #0e3a34;
            transform: translateY(-2px);
            box-shadow: 0 12px 20px -12px rgba(0, 0, 0, 0.25);
        }

        .auth-note {
            text-align: center;
            margin-top: 2rem;
            font-size: 0.85rem;
            color: #4a5b58;
        }

        .auth-note a {
            color: #b87c3a;
            text-decoration: none;
            font-weight: 600;
        }

        .auth-note a:hover {
            text-decoration: underline;
        }

        @media (max-width: 900px) {
            body {
                padding: 1rem;
            }

            .auth-panel {
                flex-direction: column;
            }

            .auth-side {
                padding: 2rem 1.5rem;
                text-align: center;
            }

            .auth-card {
                padding: 2rem 1.5rem;
            }
        }
    </style>
</head>

<body>

    <div class="auth-page">
        <div class="auth-panel">
            <div class="auth-side">
                <div class="side-top">
                    <div class="brand-mark">NE HOTEL</div>
                    <h3>Join NE Hotel</h3>
                    <p>Register now and unlock easy booking, food ordering, and full access to hotel services.</p>
                </div>
            </div>

            <div class="auth-card">
                <h2>Create Your Account</h2>
                <p>Register now to book rooms, order food, and reserve seminar halls with ease.</p>

                <?php if (!empty($errors)): ?>
                    <div class="error">
                        <?php foreach ($errors as $error): ?>
                            <p><?php echo htmlspecialchars($error); ?></p>
                        <?php endforeach; ?>
                    </div>
                <?php endif; ?>

                <form id="registerForm" method="POST" novalidate>
                    <div class="input-group" id="fullnameGroup">
                        <input class="auth-input" type="text" id="fullname" name="fullname" placeholder=" " value="<?php echo htmlspecialchars($fullname_value); ?>" required>
                        <label class="input-label">Full Name *</label>
                        <div class="field-error">Full name is required.</div>
                    </div>

                    <div class="input-group" id="emailGroup">
                        <input class="auth-input" type="email" id="email" name="email" placeholder=" " value="<?php echo htmlspecialchars($email_value); ?>" required>
                        <label class="input-label">Email *</label>
                        <div class="field-error">Valid email address required.</div>
                    </div>

                    <div class="input-group" id="phoneGroup">
                        <input class="auth-input" type="tel" id="phone" name="phone" placeholder=" " value="<?php echo htmlspecialchars($phone_value); ?>">
                        <label class="input-label">Phone Number</label>
                        <div class="field-error">Please enter a valid phone number.</div>
                    </div>

                    <div class="input-group" id="passwordGroup">
                        <input class="auth-input" type="password" id="password" name="password" placeholder=" " required>
                        <label class="input-label">Password * (min 6 chars)</label>
                        <div class="field-error">Password must be at least 6 characters.</div>
                        <div class="password-strength" id="passwordStrength"></div>
                    </div>

                    <div class="input-group" id="confirmGroup">
                        <input class="auth-input" type="password" id="confirm_password" name="confirm_password" placeholder=" " required>
                        <label class="input-label">Confirm Password *</label>
                        <div class="field-error">Passwords do not match.</div>
                    </div>

                    <button class="auth-button" type="submit" name="register">Create Account</button>
                </form>

                <div class="auth-note">
                    Already have an account? <a href="login.php">Login here</a>
                </div>
            </div>
        </div>
    </div>

    <script>
        const form = document.getElementById('registerForm');
        const fullnameInput = document.getElementById('fullname');
        const emailInput = document.getElementById('email');
        const phoneInput = document.getElementById('phone');
        const passwordInput = document.getElementById('password');
        const confirmInput = document.getElementById('confirm_password');

        const fullnameGroup = document.getElementById('fullnameGroup');
        const emailGroup = document.getElementById('emailGroup');
        const phoneGroup = document.getElementById('phoneGroup');
        const passwordGroup = document.getElementById('passwordGroup');
        const confirmGroup = document.getElementById('confirmGroup');

        function validateFullname() {
            const name = fullnameInput.value.trim();
            const isValid = name !== '';
            if (!isValid) fullnameGroup.classList.add('has-error');
            else fullnameGroup.classList.remove('has-error');
            return isValid;
        }

        function validateEmail() {
            const email = emailInput.value.trim();
            const isValid = email !== '' && /^[^\s@]+@([^\s@]+\.)+[^\s@]+$/.test(email);
            if (!isValid && email !== '') emailGroup.classList.add('has-error');
            else if (email === '') emailGroup.classList.add('has-error');
            else emailGroup.classList.remove('has-error');
            return isValid && email !== '';
        }

        function validatePhone() {
            const phone = phoneInput.value.trim();
            if (phone === '') {
                phoneGroup.classList.remove('has-error');
                return true;
            }
            const isValid = /^[\+\d\s\-\(\)]{5,20}$/.test(phone);
            if (!isValid) phoneGroup.classList.add('has-error');
            else phoneGroup.classList.remove('has-error');
            return isValid;
        }

        function validatePassword() {
            const pwd = passwordInput.value;
            const isValid = pwd.length >= 6;
            if (!isValid && pwd.length > 0) passwordGroup.classList.add('has-error');
            else if (pwd.length === 0) passwordGroup.classList.add('has-error');
            else passwordGroup.classList.remove('has-error');

            const strengthDiv = document.getElementById('passwordStrength');
            if (pwd.length === 0) {
                strengthDiv.innerHTML = '';
            } else {
                let strength = 'weak';
                let strengthText = 'Weak';
                if (pwd.length >= 8 && /[A-Z]/.test(pwd) && /[0-9]/.test(pwd)) {
                    strength = 'strong';
                    strengthText = 'Strong';
                } else if (pwd.length >= 6) {
                    strength = 'medium';
                    strengthText = 'Medium';
                }
                strengthDiv.innerHTML = `Password strength: <span class="strength-${strength}">${strengthText}</span>`;
            }

            if (confirmInput.value.length > 0) validateConfirm();
            return isValid;
        }

        function validateConfirm() {
            const pwd = passwordInput.value;
            const confirm = confirmInput.value;
            const isValid = pwd === confirm && pwd.length > 0;
            if (!isValid && confirm.length > 0) confirmGroup.classList.add('has-error');
            else if (confirm.length === 0 && pwd.length > 0) confirmGroup.classList.add('has-error');
            else confirmGroup.classList.remove('has-error');
            return isValid;
        }

        fullnameInput.addEventListener('input', validateFullname);
        emailInput.addEventListener('input', validateEmail);
        phoneInput.addEventListener('input', validatePhone);
        passwordInput.addEventListener('input', validatePassword);
        confirmInput.addEventListener('input', validateConfirm);

        form.addEventListener('submit', function(e) {
            const isFullnameValid = validateFullname();
            const isEmailValid = validateEmail();
            const isPhoneValid = validatePhone();
            const isPasswordValid = validatePassword();
            const isConfirmValid = validateConfirm();

            if (!isFullnameValid || !isEmailValid || !isPhoneValid || !isPasswordValid || !isConfirmValid) {
                e.preventDefault();
                alert('Please fix the errors before submitting.');
            }
        });

        document.querySelectorAll('.auth-input').forEach(inp => {
            if (!inp.hasAttribute('placeholder')) inp.setAttribute('placeholder', ' ');
        });
    </script>

</body>

</html>