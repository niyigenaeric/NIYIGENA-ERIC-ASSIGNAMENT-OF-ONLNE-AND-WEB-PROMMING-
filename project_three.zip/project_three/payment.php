<?php
// Payment Integration - Stripe
// Install: composer require stripe/stripe-php

// Configuration
define('STRIPE_API_KEY', 'sk_test_your_stripe_secret_key_here'); // Replace with your Stripe key
define('STRIPE_PUBLIC_KEY', 'pk_test_your_stripe_public_key_here'); // Replace with your Stripe key

session_start();
include "connect.php";

class PaymentProcessor {
    
    /**
     * Create payment intent for Stripe
     */
    public static function createPaymentIntent($booking_id, $amount, $user_email) {
        global $conn;
        
        // Store payment attempt in database
        $insert_query = "INSERT INTO payments (booking_id, user_id, amount, payment_method, status)
                         VALUES (?, ?, ?, ?, ?)";
        
        $user_id = $_SESSION['user_id'];
        executeQuery($insert_query, [$booking_id, $user_id, $amount, 'stripe', 'Initiated']);
        
        return [
            'success' => true,
            'message' => 'Payment intent created',
            'data' => [
                'booking_id' => $booking_id,
                'amount' => $amount,
                'currency' => 'usd'
            ]
        ];
    }
    
    /**
     * Process payment (Simulate for now, integrate real Stripe API)
     */
    public static function processPayment($booking_id, $amount, $payment_method) {
        global $conn;
        
        // Get or create payment record
        $query = "SELECT * FROM payments WHERE booking_id = ?";
        $result = executeQuery($query, [$booking_id]);
        $payment = $result['success'] && $result['result'] ? $result['result']->fetch_assoc() : null;
        
        if (!$payment) {
            $user_id = $_SESSION['user_id'];
            $create_query = "INSERT INTO payments (booking_id, user_id, amount, payment_method, status)
                             VALUES (?, ?, ?, ?, ?)";
            $create_result = executeQuery($create_query, [$booking_id, $user_id, $amount, $payment_method, 'Initiated']);
            if (!$create_result['success']) {
                return ['success' => false, 'message' => 'Unable to initiate payment'];
            }
            $payment = ['id' => $conn->insert_id];
        }
        
        // Generate transaction ID
        $transaction_id = 'TXN_' . time() . '_' . rand(1000, 9999);
        
        // Update payment status
        $update_query = "UPDATE payments SET status = ?, transaction_id = ? WHERE booking_id = ?";
        executeQuery($update_query, ['Completed', $transaction_id, $booking_id]);
        
        // Update booking status
        $booking_update = "UPDATE bookings SET status = ? WHERE id = ?";
        executeQuery($booking_update, ['Confirmed', $booking_id]);
        
        // Generate invoice
        self::generateInvoice($booking_id);
        
        return [
            'success' => true,
            'message' => 'Payment processed successfully',
            'transaction_id' => $transaction_id
        ];
    }
    
    /**
     * Generate Invoice
     */
    public static function generateInvoice($booking_id) {
        global $conn;
        
        $query = "SELECT b.*, u.fullname, u.email FROM bookings b 
                  JOIN users u ON b.user_id = u.id WHERE b.id = ?";
        $result = executeQuery($query, [$booking_id]);
        $booking = $result['result']->fetch_assoc();
        
        if (!$booking) {
            return false;
        }
        
        // Generate unique invoice number
        $invoice_number = 'INV-' . date('Ymd') . '-' . str_pad($booking_id, 4, '0', STR_PAD_LEFT);
        
        // Calculate tax (assume 18% tax)
        $tax_rate = 0.18;
        $tax_amount = $booking['total_price'] * $tax_rate;
        $final_amount = $booking['total_price'] + $tax_amount;
        
        // Insert invoice record
        $insert_query = "INSERT INTO invoices (booking_id, user_id, invoice_number, total_amount, tax_amount, status)
                         VALUES (?, ?, ?, ?, ?, ?)";
        
        executeQuery($insert_query, [
            $booking_id,
            $booking['user_id'],
            $invoice_number,
            $final_amount,
            $tax_amount,
            'Generated'
        ]);
        
        return $invoice_number;
    }
    
    /**
     * Verify payment status
     */
    public static function verifyPaymentStatus($booking_id) {
        global $conn;
        
        $query = "SELECT status, transaction_id FROM payments WHERE booking_id = ?";
        $result = executeQuery($query, [$booking_id]);
        
        if ($result['success'] && $result['result']->num_rows > 0) {
            return $result['result']->fetch_assoc();
        }
        
        return null;
    }
    
    /**
     * Process refund
     */
    public static function processRefund($booking_id, $reason = '') {
        global $conn;
        
        // Update booking status
        $booking_update = "UPDATE bookings SET status = ? WHERE id = ?";
        executeQuery($booking_update, ['Cancelled', $booking_id]);
        
        // Update payment status
        $payment_update = "UPDATE payments SET status = ? WHERE booking_id = ?";
        executeQuery($payment_update, ['Refunded', $booking_id]);
        
        return ['success' => true, 'message' => 'Refund processed'];
    }
}

// Handle payment request
if (isset($_POST['process_payment'])) {
    $booking_id = (int)$_POST['booking_id'];
    $amount = (float)$_POST['amount'];
    
    $result = PaymentProcessor::processPayment($booking_id, $amount, 'stripe');
    
    header('Content-Type: application/json');
    echo json_encode($result);
    exit;
}

?>
