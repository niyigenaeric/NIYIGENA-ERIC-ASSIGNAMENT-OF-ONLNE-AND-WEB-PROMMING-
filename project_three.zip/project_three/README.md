# NE Hotel Booking System - Complete Implementation Guide

## 📋 Overview
This is a fully functional hotel booking system with advanced features including user authentication, booking management, payment processing, invoicing, and email notifications.

---

## 🚀 Quick Start

### Step 1: Database Setup
1. Open phpMyAdmin (http://localhost/phpmyadmin)
2. Create a new database named `hotel_db`
3. Go to the SQL tab and paste the entire content from `database.sql`
4. Click Execute

### Step 2: Configure Files
1. Check `connect.php` - ensure database credentials are correct (default: localhost, root, no password)
2. Update `payment.php` - add your Stripe API keys (optional for testing)
3. Configure `email_notifications.php` with your mail server settings

### Step 3: Update Links in Files
Search and replace "https://yourhotel.com" with your actual domain in:
- `checkout.php`
- `email_notifications.php`

### Step 4: Test the System
1. Go to http://localhost/hotel_website
2. Click "Sign Up" and create an account
3. Browse and book services
4. Proceed to checkout

---

## 📁 File Structure

```
hotel_website/
├── index.html                    # Home page (public)
├── register_new.php              # NEW: User registration with validation
├── login.php                     # Login page (UPDATED: Secure password hashing)
├── logout.php                    # Logout handler
├── dashboard.php                 # Main dashboard
├── order.php                     # Order/booking items selection
├── order_form.php                # UPDATED: Secure checkout form
├── profile.php                   # NEW: User profile & booking history
├── invoices.php                  # NEW: Invoice viewing & management
├── checkout.php                  # NEW: Secure payment page
├── payment.php                   # NEW: Payment processing logic
├── email_notifications.php       # NEW: Email notification system
├── connect.php                   # UPDATED: Secure database connection
├── database.sql                  # UPDATED: Complete database schema
├── cart.php                      # Shopping cart
├── menu.html                     # Menu page
├── room.php                      # Room booking
├── gallery.php                   # Gallery
├── contact.php                   # Contact
├── css/
│   └── style.css                 # Main stylesheet
├── images/                       # Hotel images
└── README.md                     # This file
```

---

## 🔐 Security Features Implemented

✅ **Password Security**
- Passwords hashed using bcrypt (`password_hash()`)
- Secure comparison with `password_verify()`
- No MD5 hashing (weak)

✅ **SQL Injection Prevention**
- All queries use prepared statements
- Input sanitization with `mysqli_real_escape_string()`
- Parameterized queries throughout

✅ **Session Management**
- User authentication via sessions
- Session timeout handling
- Logout functionality

✅ **Data Validation**
- Email validation with `filter_var()`
- Input type checking
- Length validation

---

## 🎯 Features

### User Management
- ✅ User registration with email validation
- ✅ Secure login with password hashing
- ✅ User profile with personal information
- ✅ Session management
- ✅ Logout functionality

### Booking System
- ✅ Browse and book rooms, food, and seminar halls
- ✅ Add items to shopping cart
- ✅ Modify quantities
- ✅ Checkout with booking details
- ✅ Special requests/notes

### Booking Management
- ✅ View all bookings with status
- ✅ Track booking history
- ✅ Cancel pending bookings
- ✅ Booking statistics

### Payment System
- ✅ Secure payment gateway integration
- ✅ Multiple payment methods support
- ✅ Transaction tracking
- ✅ Payment status management
- ✅ Automatic invoice generation

### Invoicing
- ✅ Automatic invoice generation
- ✅ Invoice viewing and download
- ✅ Tax calculation (18%)
- ✅ Invoice numbering system
- ✅ Payment tracking

### Email Notifications
- ✅ Booking confirmation emails
- ✅ Payment confirmation emails
- ✅ Invoice emails
- ✅ HTML formatted templates
- ✅ Email logging

### Database
- ✅ Users management
- ✅ Menu items
- ✅ Rooms management
- ✅ Seminar halls
- ✅ Bookings tracking
- ✅ Payments tracking
- ✅ Invoices generation
- ✅ Email logs
- ✅ Reviews system (structure)

---

## 📊 Database Tables

### users
- id, fullname, email, password, phone, address, timestamps

### bookings
- id, user_id, booking_type, item_id, item_name, quantity
- booking_date, check_in_date, check_out_date, total_price, status, notes

### payments
- id, booking_id, user_id, amount, payment_method, transaction_id, status

### invoices
- id, booking_id, user_id, invoice_number, total_amount, tax_amount, discount_amount, status

### menu_items, rooms, seminar_halls, reviews, notifications, email_logs

---

## 💳 Payment Integration

### Testing Payment
1. Go to user profile
2. Click on a pending booking
3. Fill in payment details:
   - Card: 4242 4242 4242 4242 (test card)
   - Expiry: 12/25
   - CVV: 123
4. Click "Pay"

### Stripe Integration (Optional)
To use real Stripe payments:
1. Get API keys from https://stripe.com
2. Update `payment.php` with your keys
3. Install Stripe PHP library: `composer require stripe/stripe-php`

---

## 📧 Email Configuration

### Using PHP Mail Function
Update credentials in `email_notifications.php`:
```php
// For Gmail
$this->headers .= "From: your-email@gmail.com" . "\r\n";
```

### Using SMTP (Recommended)
Install PHPMailer:
```bash
composer require phpmailer/phpmailer
```

Then update `email_notifications.php` to use PHPMailer instead of `mail()`.

---

## 🔧 Configuration

### Database Connection (connect.php)
```php
$servername = "localhost";
$username = "root";
$password = "";
$database = "hotel_db";
```

### Email Settings (email_notifications.php)
```php
define('MAIL_FROM', 'noreply@nehotel.com');
define('MAIL_HOST', 'smtp.gmail.com');
define('MAIL_PORT', 587);
```

### Payment Settings (payment.php)
```php
define('STRIPE_API_KEY', 'your_stripe_secret_key');
define('STRIPE_PUBLIC_KEY', 'your_stripe_public_key');
```

---

## 📱 User Workflow

### 1. **Registration & Login**
- New users register via `register_new.php`
- Passwords are hashed securely
- Login at `login.php`

### 2. **Browse & Book**
- Dashboard shows available services
- Browse menu, rooms, seminar halls
- Add items to cart
- Proceed to order form

### 3. **Checkout**
- Fill in booking details
- Review order summary
- Proceed to payment

### 4. **Payment**
- Choose payment method
- Enter card details (test or real)
- Complete payment
- Invoice generated automatically

### 5. **Tracking**
- View all bookings in profile
- Check payment status
- Download invoices
- Cancel pending bookings

---

## 🧪 Testing Checklist

- [ ] User registration works
- [ ] Login with correct credentials
- [ ] Add items to cart
- [ ] Checkout process completes
- [ ] Payment processed
- [ ] Invoice generated
- [ ] Profile shows bookings
- [ ] Can cancel pending booking
- [ ] Logout works
- [ ] Redirects work correctly

---

## 🐛 Troubleshooting

### Database Connection Error
- Check phpMyAdmin is running
- Verify credentials in `connect.php`
- Ensure `hotel_db` database exists

### Login Issues
- Clear browser cookies
- Check user exists in database
- Verify password is correct

### Email Not Sending
- Check mail function is enabled
- Verify email settings
- Check email logs table

### Payment Issues
- Check connection to payment gateway
- Verify API keys
- Check payment table status

---

## 📈 Future Enhancements

- [ ] Reviews and ratings system
- [ ] SMS notifications
- [ ] Multiple currency support
- [ ] Discount codes/coupons
- [ ] Staff management panel
- [ ] Analytics dashboard
- [ ] Mobile app
- [ ] Live chat support
- [ ] Loyalty program
- [ ] Advanced search filters

---

## 📞 Support

For technical issues:
- Email: support@nehotel.com
- Phone: +250 780 581 260
- Website: www.nehotel.com

---

## 📄 License

© 2026 NE Hotel Kigali. All Rights Reserved.

**Last Updated:** April 14, 2026
