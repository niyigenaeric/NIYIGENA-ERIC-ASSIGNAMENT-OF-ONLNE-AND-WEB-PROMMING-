<?php
session_start();
include "connect.php";

// Check if user is logged in
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

$page_title = "Invoices";

// Get fullname from session
$fullname = isset($_SESSION['fullname']) ? explode(' ', $_SESSION['fullname'])[0] : 'Guest';

$user_id = $_SESSION['user_id'];

// Get invoice details
$invoice_id = isset($_GET['id']) ? (int)$_GET['id'] : 0;

if ($invoice_id > 0) {
    $query = "SELECT i.*, b.*, u.fullname, u.email, u.phone, u.address 
              FROM invoices i
              JOIN bookings b ON i.booking_id = b.id
              JOIN users u ON i.user_id = u.id
              WHERE i.id = ? AND i.user_id = ?";
    
    $result = executeQuery($query, [$invoice_id, $user_id]);
    
    if ($result['success'] && $result['result']->num_rows > 0) {
        $invoice = $result['result']->fetch_assoc();
    } else {
        header("Location: profile.php");
        exit();
    }
} else {
    // Get all invoices for user
    $query = "SELECT i.*, b.item_name, b.quantity, b.total_price 
              FROM invoices i
              JOIN bookings b ON i.booking_id = b.id
              WHERE i.user_id = ?
              ORDER BY i.created_at DESC";
    
    $result = executeQuery($query, [$user_id]);
}

function pdfEscape($text) {
    return str_replace(['\\', '(', ')'], ['\\\\', '\\(', '\\)'], $text);
}

function buildInvoicePdf($invoice) {
    $lines = [];
    $lines[] = 'BT';
    $lines[] = '/F1 18 Tf';
    $lines[] = '50 740 Td (' . pdfEscape('INVOICE ' . $invoice['invoice_number']) . ') Tj';
    $lines[] = '0 -28 Td /F1 12 Tf (' . pdfEscape('Date: ' . date('F d, Y', strtotime($invoice['created_at']))) . ') Tj';
    $lines[] = '0 -20 Td (' . pdfEscape('Status: ' . $invoice['status']) . ') Tj';
    $lines[] = '0 -30 Td /F1 14 Tf (' . pdfEscape('Bill To:') . ') Tj';
    $lines[] = '0 -22 Td /F1 12 Tf (' . pdfEscape($invoice['fullname']) . ') Tj';
    $lines[] = '0 -18 Td (' . pdfEscape($invoice['email']) . ') Tj';
    $lines[] = '0 -18 Td (' . pdfEscape($invoice['phone']) . ') Tj';
    $lines[] = '0 -30 Td /F1 14 Tf (' . pdfEscape('Invoice Details:') . ') Tj';
    $lines[] = '0 -22 Td /F1 12 Tf (' . pdfEscape('Description: ' . $invoice['item_name']) . ') Tj';
    $lines[] = '0 -18 Td (' . pdfEscape('Quantity: ' . $invoice['quantity']) . ') Tj';
    $lines[] = '0 -18 Td (' . pdfEscape('Unit Price: $' . number_format($invoice['total_price'] / max(1, $invoice['quantity']), 2)) . ') Tj';
    $lines[] = '0 -18 Td (' . pdfEscape('Amount: $' . number_format($invoice['total_price'], 2)) . ') Tj';
    $lines[] = '0 -30 Td (' . pdfEscape('Tax: $' . number_format($invoice['tax_amount'], 2)) . ') Tj';
    if (!empty($invoice['discount_amount']) && $invoice['discount_amount'] > 0) {
        $lines[] = '0 -18 Td (' . pdfEscape('Discount: -$' . number_format($invoice['discount_amount'], 2)) . ') Tj';
    }
    $lines[] = '0 -18 Td (' . pdfEscape('Total: $' . number_format($invoice['total_amount'], 2)) . ') Tj';
    if (!empty($invoice['notes'])) {
        $lines[] = '0 -30 Td /F1 14 Tf (' . pdfEscape('Notes:') . ') Tj';
        $lines[] = '0 -22 Td /F1 12 Tf (' . pdfEscape($invoice['notes']) . ') Tj';
    }
    $lines[] = 'ET';

    $stream = implode("\n", $lines);
    $stream = str_replace("\n", "\r\n", $stream);

    $objects = [];
    $objects[] = "1 0 obj\n<< /Type /Catalog /Pages 2 0 R >>\nendobj";
    $objects[] = "2 0 obj\n<< /Type /Pages /Kids [3 0 R] /Count 1 >>\nendobj";
    $objects[] = "3 0 obj\n<< /Type /Page /Parent 2 0 R /MediaBox [0 0 612 792] /Resources << /Font << /F1 4 0 R >> >> /Contents 5 0 R >>\nendobj";
    $objects[] = "4 0 obj\n<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica >>\nendobj";
    $objects[] = "5 0 obj\n<< /Length " . strlen($stream) . " >>\nstream\n" . $stream . "\nendstream\nendobj";

    $offset = 0;
    $xref = [0];
    $pdf = "%PDF-1.4\n";
    foreach ($objects as $obj) {
        $xref[] = $offset;
        $pdf .= $obj . "\n";
        $offset += strlen($obj) + 1;
    }
    $xrefPos = strlen($pdf);
    $pdf .= "xref\n0 " . count($xref) . "\n";
    foreach ($xref as $pos) {
        $pdf .= sprintf("%010d 00000 n \n", $pos);
    }
    $pdf .= "trailer\n<< /Size " . count($xref) . " /Root 1 0 R >>\nstartxref\n" . $xrefPos . "\n%%EOF";

    return $pdf;
}

function buildInvoiceWord($invoice) {
    $html = "<html><head><meta charset=\"UTF-8\"></head><body>";
    $html .= "<h1>Invoice " . htmlspecialchars($invoice['invoice_number']) . "</h1>";
    $html .= "<p><strong>Date:</strong> " . htmlspecialchars(date('F d, Y', strtotime($invoice['created_at']))) . "</p>";
    $html .= "<p><strong>Status:</strong> " . htmlspecialchars($invoice['status']) . "</p>";
    $html .= "<h2>Bill To</h2>";
    $html .= "<p>" . htmlspecialchars($invoice['fullname']) . "<br>" . htmlspecialchars($invoice['email']) . "<br>" . htmlspecialchars($invoice['phone']) . "</p>";
    $html .= "<h2>Invoice Details</h2>";
    $html .= "<p><strong>Description:</strong> " . htmlspecialchars($invoice['item_name']) . "</p>";
    $html .= "<p><strong>Quantity:</strong> " . htmlspecialchars($invoice['quantity']) . "</p>";
    $html .= "<p><strong>Unit Price:</strong> $" . number_format($invoice['total_price'] / max(1, $invoice['quantity']), 2) . "</p>";
    $html .= "<p><strong>Amount:</strong> $" . number_format($invoice['total_price'], 2) . "</p>";
    $html .= "<p><strong>Tax:</strong> $" . number_format($invoice['tax_amount'], 2) . "</p>";
    if (!empty($invoice['discount_amount'])) {
        $html .= "<p><strong>Discount:</strong> -$" . number_format($invoice['discount_amount'], 2) . "</p>";
    }
    $html .= "<h3>Total: $" . number_format($invoice['total_amount'], 2) . "</h3>";
    if (!empty($invoice['notes'])) {
        $html .= "<h3>Notes</h3><p>" . nl2br(htmlspecialchars($invoice['notes'])) . "</p>";
    }
    $html .= "</body></html>";
    return $html;
}

function outputInvoiceDownload($invoice, $format) {
    if ($format === 'word') {
        $content = buildInvoiceWord($invoice);
        header('Content-Type: application/msword');
        header('Content-Disposition: attachment; filename="' . $invoice['invoice_number'] . '.doc"');
        echo $content;
        exit;
    }

    $pdf = buildInvoicePdf($invoice);
    header('Content-Type: application/pdf');
    header('Content-Disposition: attachment; filename="' . $invoice['invoice_number'] . '.pdf"');
    echo $pdf;
    exit;
}

// Handle download request
if (isset($_GET['download'])) {
    $format = isset($_GET['format']) && $_GET['format'] === 'word' ? 'word' : 'pdf';
    outputInvoiceDownload($invoice, $format);
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo isset($invoice) ? "Invoice " . $invoice['invoice_number'] : "Invoices"; ?> | NE Hotel</title>
    <link rel="stylesheet" href="css/style.css">
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        body {
            font-family: 'Arial', sans-serif;
            background: #f5f5f5;
            padding-top: 80px;
        }
        .container {
            max-width: 900px;
            margin: 30px auto;
            padding: 20px;
        }

        /* Invoice View */
        .invoice-container {
            background: white;
            padding: 40px;
            border-radius: 10px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
        }
        .invoice-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 40px;
            border-bottom: 2px solid #8b6f47;
            padding-bottom: 20px;
        }
        .invoice-header h1 {
            color: #8b6f47;
        }
        .invoice-header .invoice-status {
            background: #28a745;
            color: white;
            padding: 10px 20px;
            border-radius: 5px;
            font-weight: bold;
        }
        .invoice-info {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 30px;
            margin-bottom: 30px;
        }
        .info-section h3 {
            color: #8b6f47;
            margin-bottom: 10px;
            font-size: 14px;
            text-transform: uppercase;
        }
        .info-section p {
            color: #666;
            font-size: 14px;
            line-height: 1.8;
            margin-bottom: 5px;
        }
        .invoice-items {
            margin: 30px 0;
            border-collapse: collapse;
            width: 100%;
        }
        .invoice-items thead {
            background: #f0f0f0;
        }
        .invoice-items th {
            padding: 12px;
            text-align: left;
            color: #8b6f47;
            font-weight: bold;
            border-bottom: 2px solid #8b6f47;
        }
        .invoice-items td {
            padding: 12px;
            border-bottom: 1px solid #ddd;
        }
        .invoice-summary {
            display: flex;
            justify-content: flex-end;
            margin-top: 30px;
            padding-top: 20px;
            border-top: 2px solid #8b6f47;
        }
        .summary-table {
            width: 300px;
        }
        .summary-row {
            display: flex;
            justify-content: space-between;
            padding: 8px 0;
            font-size: 14px;
        }
        .summary-row.total {
            font-size: 18px;
            font-weight: bold;
            color: #8b6f47;
            border-top: 1px solid #ddd;
            padding-top: 10px;
            margin-top: 10px;
        }
        .actions {
            display: flex;
            gap: 10px;
            margin-top: 30px;
            justify-content: center;
        }
        .btn {
            padding: 12px 25px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            font-size: 14px;
            text-decoration: none;
            display: inline-block;
        }
        .btn-primary {
            background: #8b6f47;
            color: white;
        }
        .btn-primary:hover {
            background: #6b5436;
        }
        .btn-secondary {
            background: #6c757d;
            color: white;
        }
        .btn-secondary:hover {
            background: #5a6268;
        }

        /* Invoices List */
        .invoices-list {
            background: white;
            border-radius: 10px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
            overflow: hidden;
        }
        .list-item {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 20px;
            border-bottom: 1px solid #eee;
        }
        .list-item:hover {
            background: #f9f9f9;
        }
        .list-info {
            flex: 1;
        }
        .list-info h4 {
            color: #8b6f47;
            margin-bottom: 5px;
        }
        .list-info p {
            color: #666;
            font-size: 13px;
        }
        .list-amount {
            font-size: 18px;
            font-weight: bold;
            color: #8b6f47;
            min-width: 100px;
            text-align: right;
            margin: 0 20px;
        }
        .list-actions {
            display: flex;
            gap: 10px;
        }
        .btn-small {
            padding: 8px 15px;
            font-size: 12px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            text-decoration: none;
            display: inline-block;
        }
        .btn-view {
            background: #8b6f47;
            color: white;
        }
        .btn-view:hover {
            background: #6b5436;
        }
        .btn-download {
            background: #28a745;
            color: white;
        }
        .btn-download:hover {
            background: #218838;
        }

        /* Print Styles */
        @media print {
            .navbar, .actions, .btn-actions {
                display: none;
            }
            body {
                background: white;
            }
            .invoice-container {
                box-shadow: none;
                padding: 0;
            }
        }
    </style>
</head>
<body>

    <div class="container">
        
        <?php if (isset($invoice)): ?>
            <!-- Single Invoice View -->
            <div class="invoice-container">
                
                <div class="invoice-header">
                    <div>
                        <h1>🧾 INVOICE</h1>
                        <p style="color:#666;"><?php echo $invoice['invoice_number']; ?></p>
                    </div>
                    <div class="invoice-status">
                        <?php echo $invoice['status']; ?>
                    </div>
                </div>

                <div class="invoice-info">
                    <div class="info-section">
                        <h3>From</h3>
                        <p><strong>NE Hotel Kigali</strong></p>
                        <p>info@nehotel.com</p>
                        <p>+250 780 581 260</p>
                    </div>

                    <div class="info-section">
                        <h3>Bill To</h3>
                        <p><strong><?php echo htmlspecialchars($invoice['fullname']); ?></strong></p>
                        <p><?php echo htmlspecialchars($invoice['email']); ?></p>
                        <p><?php echo htmlspecialchars($invoice['phone']); ?></p>
                    </div>
                </div>

                <div class="invoice-info">
                    <div class="info-section">
                        <h3>Invoice Date</h3>
                        <p><?php echo date('F d, Y', strtotime($invoice['created_at'])); ?></p>
                    </div>
                    <div class="info-section">
                        <h3>Invoice Number</h3>
                        <p><?php echo $invoice['invoice_number']; ?></p>
                    </div>
                </div>

                <table class="invoice-items">
                    <thead>
                        <tr>
                            <th>Description</th>
                            <th style="text-align:center;">Quantity</th>
                            <th style="text-align:right;">Unit Price</th>
                            <th style="text-align:right;">Amount</th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr>
                            <td><?php echo htmlspecialchars($invoice['item_name']); ?></td>
                            <td style="text-align:center;"><?php echo $invoice['quantity']; ?></td>
                            <td style="text-align:right;">$<?php echo number_format($invoice['total_price'] / $invoice['quantity'], 2); ?></td>
                            <td style="text-align:right;">$<?php echo number_format($invoice['total_price'], 2); ?></td>
                        </tr>
                    </tbody>
                </table>

                <div class="invoice-summary">
                    <div class="summary-table">
                        <div class="summary-row">
                            <span>Subtotal</span>
                            <span>$<?php echo number_format($invoice['total_price'], 2); ?></span>
                        </div>
                        <div class="summary-row">
                            <span>Tax (18%)</span>
                            <span>$<?php echo number_format($invoice['tax_amount'], 2); ?></span>
                        </div>
                        <?php if ($invoice['discount_amount'] > 0): ?>
                        <div class="summary-row">
                            <span>Discount</span>
                            <span>-$<?php echo number_format($invoice['discount_amount'], 2); ?></span>
                        </div>
                        <?php endif; ?>
                        <div class="summary-row total">
                            <span>Total</span>
                            <span>$<?php echo number_format($invoice['total_amount'], 2); ?></span>
                        </div>
                    </div>
                </div>

                <div class="actions">
                    <button class="btn btn-primary" onclick="window.print()">🖨️ Print</button>
                    <a href="invoices.php?id=<?php echo $invoice['id']; ?>&download=1&format=pdf" class="btn btn-view">Download PDF</a>
                    <a href="invoices.php?id=<?php echo $invoice['id']; ?>&download=1&format=word" class="btn btn-download">Download Word</a>
                    <a href="invoices.php" class="btn btn-secondary">← Back to Invoices</a>
                </div>

            </div>

        <?php else: ?>
            <!-- Invoices List -->
            <h2 style="margin-bottom: 20px; color: #8b6f47;">📋 My Invoices</h2>
            
            <?php if ($result['success'] && $result['result']->num_rows > 0): ?>
                <div class="invoices-list">
                    <?php while ($inv = $result['result']->fetch_assoc()): ?>
                        <div class="list-item">
                            <div class="list-info">
                                <h4><?php echo $inv['invoice_number']; ?></h4>
                                <p>Item: <?php echo htmlspecialchars($inv['item_name']); ?> (Qty: <?php echo $inv['quantity']; ?>)</p>
                                <p style="color:#999; font-size:12px;">Created: <?php echo date('F d, Y', strtotime($inv['created_at'])); ?></p>
                            </div>
                            <div class="list-amount">$<?php echo number_format($inv['total_amount'], 2); ?></div>
                            <div class="list-actions">
                                <a href="invoices.php?id=<?php echo $inv['id']; ?>" class="btn-small btn-view">View</a>
                                <a href="invoices.php?id=<?php echo $inv['id']; ?>&download=1&format=pdf" class="btn-small btn-download">PDF</a>
                                <a href="invoices.php?id=<?php echo $inv['id']; ?>&download=1&format=word" class="btn-small btn-view">DOC</a>
                            </div>
                        </div>
                    <?php endwhile; ?>
                </div>
            <?php else: ?>
                <div style="text-align:center; padding:40px; background:white; border-radius:10px;">
                    <p style="color:#999;">No invoices yet.</p>
                </div>
            <?php endif; ?>

        <?php endif; ?>

    </div>

    <!-- ================= FOOTER ================= -->
    <div class="footer">

        <div class="footer-container">

            <div>
                <h3>NE Hotel</h3>
                <p>Your comfort, our priority.</p>
            </div>

            <div>
                <h4>Quick Links</h4>
                <a href="dashboard.php">Home</a>
                <a href="about.php">About Us</a>
                <a href="menu.php">Menu</a>
                <a href="order.php">Order</a>
                <a href="gallery.php">Gallery</a>
                <a href="contact.php">Contact Us</a>
            </div>

            <div>
                <h4>Contact</h4>
                <p>Email: info@nehotel.com</p>
                <p>Phone: +250 780 581 260</p>
                <div style="margin-top:15px;">
                    <p style="margin:5px 0; font-size:14px;"><strong>Follow Us:</strong></p>
                    <a href="https://x.com/ntongesten" target="_blank" style="color:#ddd; text-decoration:none; display:inline-block; margin:5px 5px 5px 0;">𝕏 Twitter</a>
                    <a href="https://www.facebook.com/erickseniz" target="_blank" style="color:#ddd; text-decoration:none; display:inline-block; margin:5px 5px;">📘 Facebook</a>
                    <a href="https://wa.me/250780581260" target="_blank" style="color:#ddd; text-decoration:none; display:inline-block; margin:5px 0;">📱 WhatsApp</a>
                </div>
            </div>

        </div>

        <!-- COPYRIGHT -->
        <div style="text-align:center; margin-top:20px; padding-top:15px; border-top:1px solid #444; color:#ddd;">
            © <?php echo date("Y"); ?> NE Hotel. All Rights Reserved.
        </div>

    </div>

    <script src="active-nav.js"></script>

    <?php include "includes/footer.php"; ?>

