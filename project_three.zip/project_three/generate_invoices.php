<?php
// Script to generate invoices for existing bookings
session_start();
include "connect.php";

// Check if user is admin (you might want to add admin check here)
if (!isset($_SESSION['user_id'])) {
    die("Access denied. Please login first.");
}

echo "<h1>Generating Invoices for Existing Bookings</h1>";

// Get all bookings that don't have invoices yet
$query = "SELECT b.* FROM bookings b
          LEFT JOIN invoices i ON b.id = i.booking_id
          WHERE i.id IS NULL";

$result = executeQuery($query);

if ($result['success'] && $result['result']->num_rows > 0) {
    $count = 0;

    while ($booking = $result['result']->fetch_assoc()) {
        // Generate invoice for this booking
        $invoice_number = 'INV-' . date('Ymd', strtotime($booking['created_at'])) . '-' . str_pad($booking['id'], 4, '0', STR_PAD_LEFT);

        // Calculate tax (18% tax)
        $tax_rate = 0.18;
        $tax_amount = $booking['total_price'] * $tax_rate;
        $final_amount = $booking['total_price'] + $tax_amount;

        // Insert invoice record
        $insert_query = "INSERT INTO invoices (booking_id, user_id, invoice_number, total_amount, tax_amount, status)
                         VALUES (?, ?, ?, ?, ?, ?)";

        $insert_result = executeQuery($insert_query, [
            $booking['id'],
            $booking['user_id'],
            $invoice_number,
            $final_amount,
            $tax_amount,
            'Generated'
        ]);

        if ($insert_result['success']) {
            $count++;
            echo "Generated invoice {$invoice_number} for booking #{$booking['id']}<br>";
        } else {
            echo "Failed to generate invoice for booking #{$booking['id']}: " . $insert_result['error'] . "<br>";
        }
    }

    echo "<br><strong>Total invoices generated: {$count}</strong>";
} else {
    echo "No bookings found that need invoices.";
}

echo "<br><br><a href='dashboard.php'>Back to Dashboard</a>";
?>