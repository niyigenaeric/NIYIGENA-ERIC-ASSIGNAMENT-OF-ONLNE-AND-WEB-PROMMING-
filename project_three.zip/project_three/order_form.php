<?php
session_start();
include "connect.php";

// Check if user is logged in
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

// Get fullname from session
$fullname = isset($_SESSION['fullname']) ? explode(' ', $_SESSION['fullname'])[0] : 'Guest';

$user_id = $_SESSION['user_id'];
$cart = $_SESSION['cart'] ?? [];

// Keep only valid cart items with required fields
$cart = array_values(array_filter($cart, function ($item) {
    return is_array($item)
        && isset($item['name'], $item['price'], $item['qty'])
        && $item['name'] !== ''
        && is_numeric($item['price'])
        && is_numeric($item['qty']);
}));

if (!empty($_SESSION['selected_items']) && is_array($_SESSION['selected_items'])) {
    $selectedCart = [];
    foreach ($_SESSION['selected_items'] as $selectedIndex) {
        if (isset($cart[$selectedIndex]) && is_array($cart[$selectedIndex])) {
            $selectedCart[] = $cart[$selectedIndex];
        }
    }
    if (!empty($selectedCart)) {
        $cart = $selectedCart;
    }
}

$showPopup = false;
$booking_ids = [];
$total_amount = 0;

$showPopup = false;
$booking_ids = [];
$total_amount = 0;
$showError = false;
$errorMessage = '';

if (isset($_POST['submit'])) {

    $fullname = sanitize($_POST['fullname']);
    $email = sanitize($_POST['email']);
    $phone = sanitize($_POST['phone']);
    $booking_date = date('Y-m-d');
    $delivery_address = sanitize($_POST['room_number']);
    $delivery_date = sanitize($_POST['delivery_date']);
    $delivery_time = sanitize($_POST['delivery_time']);
    $order_type = sanitize($_POST['order_type'] ?? 'Delivery');
    $payment_method = sanitize($_POST['payment_method'] ?? 'Credit Card');
    $cc_number = preg_replace('/\D/', '', $_POST['cc_number'] ?? '');
    $card_last4 = $cc_number ? substr($cc_number, -4) : null;
    $notes = sanitize($_POST['notes'] ?? '');
    $notes .= "\nRoom Number: " . $delivery_address;

    foreach ($cart as $c) {
        if (!isset($c['name'], $c['price'], $c['qty'])) {
            continue;
        }

        $item = sanitize($c['name']);
        $qty = (int)$c['qty'];
        $price = (float)$c['price'];
        $total_price = $qty * $price;
        $total_amount += $total_price;

        // Use prepared statement to insert booking
        $insert_query = "INSERT INTO bookings (user_id, booking_type, item_id, item_name, guest_fullname, contact_email, contact_phone, room_id, adults, children, room_preference, smoking_preference, bed_type, arrival_time, payment_method, card_last4, guarantee_amount, cancellation_policy_ack, quantity, booking_date, check_in_date, check_out_date, number_of_people, total_price, status, notes)
                         VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";

        $result = executeQuery($insert_query, [
            $user_id,
            'Food',
            0,
            $item,
            $fullname,
            $email,
            $phone,
            0,
            0,
            0,
            '',
            '',
            '',
            $delivery_time,
            $payment_method,
            $card_last4,
            0,
            0,
            $qty,
            $booking_date,
            $delivery_date,
            '',
            1,
            $total_price,
            'Pending',
            $notes
        ]);

        if ($result['success']) {
            $booking_ids[] = $conn->insert_id;
        } else {
            $errorMessage = 'Failed to place order for ' . $item . '. ' . ($result['error'] ?? 'Unknown error.');
            $showError = true;
            break; // Stop on first error
        }
    }

    if (!empty($booking_ids) && !$showError) {
        $showPopup = true;
    } elseif (empty($booking_ids) && !$showError) {
        $showError = true;
        $errorMessage = 'Failed to place order. Please try again.';
    }
}
?>

<!DOCTYPE html>
<html>

<head>
    <title>Food Order Checkout | NE Hotel</title>
    <link rel="stylesheet" href="css/style.css">
    <style>
        body {
            font-family: Arial;
            background: #f5f5f5;
            margin: 0;
            padding-top: 80px;
        }

        .container {
            max-width: 600px;
            margin: 30px auto;
            padding: 20px;
            background: white;
            border-radius: 10px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
        }
        h2 {
            text-align: center;
            color: #8b6f47;
        }
        form {
            display: flex;
            flex-direction: column;
        }
        input, textarea {
            padding: 12px;
            margin: 10px 0;
            border: 1px solid #ddd;
            border-radius: 5px;
            font-size: 14px;
            font-family: Arial;
        }
        input:focus, textarea:focus {
            outline: none;
            border-color: #8b6f47;
            box-shadow: 0 0 5px rgba(139, 111, 71, 0.3);
        }
        button {
            padding: 12px;
            background: #28a745;
            color: white;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            font-weight: bold;
            margin-top: 15px;
        }
        button:hover {
            background: #218838;
        }
        .summary {
            background: #f9f9f9;
            padding: 15px;
            border-radius: 5px;
            margin-bottom: 20px;
        }
        .summary h3 {
            color: #8b6f47;
            margin-bottom: 10px;
        }
        .summary-item {
            display: flex;
            justify-content: space-between;
            padding: 8px;
            border-bottom: 1px solid #ddd;
        }
        .summary-item:last-child {
            border-bottom: none;
        }
        .total {
            font-weight: bold;
            color: #8b6f47;
            font-size: 16px;
            padding: 10px 0;
            border-top: 2px solid #8b6f47;
            margin-top: 10px;
        }
        /* Modal */
        .modal {
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: rgba(0, 0, 0, 0.6);
            display: none;
            justify-content: center;
            align-items: center;
            z-index: 1000;
        }
        .modal-content {
            background: white;
            padding: 30px;
            border-radius: 10px;
            max-width: 500px;
            box-shadow: 0 4px 20px rgba(0,0,0,0.3);
        }
        .modal-content h2 {
            color: #28a745;
            margin-top: 0;
        }
        .modal-content a {
            display: inline-block;
            margin-top: 15px;
            padding: 10px 20px;
            background: #8b6f47;
            color: white;
            text-decoration: none;
            border-radius: 5px;
        }
        .modal-content a:hover {
            background: #6d5435;
        }
    </style>
</head>

<body>

    <!-- NAVBAR -->
    <div class="navbar">
        <div class="logo">
            <h2>NE Hotel</h2>
        </div>
        <div class="menu">
            <a href="dashboard.php">Home</a>
            <a href="about.php">About Us</a>
            <a href="menu.php">Menu</a>
            <a href="order.php">Order</a>
            <a href="gallery.php">Gallery</a>
            <a href="contact.php">Contact Us</a>
        </div>
        <div class="auth">
            <span>Hello, <?php echo $fullname; ?></span>
            <a href="logout.php">Logout</a>
        </div>
    </div>

    <div class="container">

        <h2>🍽️ Food Order Checkout</h2>

        <!-- ORDER SUMMARY -->
        <div class="summary">
            <h3>Food Order Summary</h3>
            <?php
            $total = 0;
            foreach ($cart as $item):
                if (!isset($item['name'], $item['price'], $item['qty'])) {
                    continue;
                }
                $item_total = $item['qty'] * $item['price'];
                $total += $item_total;
            ?>
                <div class="summary-item">
                    <span><?php echo htmlspecialchars($item['name']); ?> x<?php echo $item['qty']; ?></span>
                    <span>$<?php echo number_format($item_total, 2); ?></span>
                </div>
            <?php endforeach; ?>
            <div class="total">
                Total: $<?php echo number_format($total, 2); ?>
            </div>
        </div>

        <!-- CHECKOUT FORM -->
        <form method="POST">

            <input type="text" name="fullname" placeholder="Full Name" required value="<?php echo htmlspecialchars($_SESSION['fullname'] ?? ''); ?>">
            <input type="email" name="email" placeholder="Email" required value="<?php echo htmlspecialchars($_SESSION['email'] ?? ''); ?>">
            <input type="tel" name="phone" placeholder="Phone" required>

            <input type="text" name="room_number" placeholder="Room Number/Type" required>

            <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(220px, 1fr)); gap: 12px;">
                <input type="date" name="delivery_date" required>
                <input type="time" name="delivery_time" required placeholder="Delivery Time">
            </div>

            <select name="order_type" required>
                <option value="">Order Type</option>
                <option value="Delivery">Delivery</option>
                <option value="Pickup">Pickup</option>
            </select>

            <select name="payment_method" required>
                <option value="">Payment Method</option>
                <option value="Credit Card">Credit Card</option>
                <option value="Cash on Delivery">Cash on Delivery</option>
            </select>

            <input type="text" name="cc_number" placeholder="Credit card number (optional)" maxlength="19">
            <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(140px, 1fr)); gap: 12px;">
                <input type="text" name="cc_expiry" placeholder="Expiry MM/YY (optional)">
                <input type="text" name="cc_cvc" placeholder="CVC (optional)">
            </div>

            <textarea name="notes" placeholder="Special requests or notes (optional)" rows="4"></textarea>

            <button type="submit" name="submit">✅ Confirm & Proceed</button>

        </form>

    </div>

    <!-- SUCCESS POPUP -->
    <?php if ($showPopup): ?>

        <div class="modal" style="display: flex;">

            <div class="modal-content">

                <h2>✅ Order Successful!</h2>

                <p>Your food order has been placed successfully.</p>

                <p><strong>📅 Order ID:</strong> #<?php echo implode(', #', $booking_ids); ?></p>
                <p><strong>💰 Total Amount:</strong> $<?php echo number_format($total_amount, 2); ?></p>
                <p><strong>📊 Status:</strong> Pending Payment</p>

                <h3>Ordered Items:</h3>
                <ul style="text-align: left; padding-left: 20px;">
                    <?php foreach ($cart as $c): ?>
                        <li><?php echo htmlspecialchars($c['name']); ?> (Qty: <?php echo $c['qty']; ?>) - $<?php echo number_format($c['qty'] * $c['price'], 2); ?></li>
                    <?php endforeach; ?>
                </ul>

                <p style="color: #666; font-size: 13px; margin-top: 15px;">
                    📧 A confirmation email has been sent to <strong><?php echo htmlspecialchars($email); ?></strong>
                </p>

                <a href="profile.php">📋 View My Bookings</a>
                <a href="dashboard.php" style="margin-left: 10px;">🏠 Back to Home</a>

            </div>

        </div>

    <?php unset($_SESSION['cart']); endif; ?>

    <!-- ERROR POPUP -->
    <?php if ($showError): ?>

        <div class="modal" style="display: flex;">

            <div class="modal-content">

                <h2>❌ Order Failed</h2>

                <p><?php echo htmlspecialchars($errorMessage); ?></p>

                <a href="javascript:history.back()">🔙 Go Back</a>
                <a href="dashboard.php" style="margin-left: 10px;">🏠 Back to Home</a>

            </div>

        </div>

    <?php endif; ?>

    <!-- FOOTER -->
    <div class="footer">
        <div class="footer-container">
            <div>
                <h3>NE Hotel</h3>
                <p>Your comfort, our priority.</p>
            </div>
            <div>
                <h4>Quick Links</h4>
                <a href="dashboard.php">Home</a>
                <a href="about.php">About Us</a>
                <a href="menu.php">Menu</a>
                <a href="order.php">Order</a>
                <a href="gallery.php">Gallery</a>
                <a href="contact.php">Contact Us</a>
            </div>
            <div>
                <h4>Contact</h4>
                <p>Email: info@nehotel.com</p>
                <p>Phone: +250 780 581 260</p>
                <div style="margin-top:15px;">
                    <p style="margin:5px 0; font-size:14px;"><strong>Follow Us:</strong></p>
                    <a href="https://x.com/ntongesten" target="_blank" style="color:#ddd; text-decoration:none; display:inline-block; margin:5px 5px 5px 0;">𝕏 Twitter</a>
                    <a href="https://www.facebook.com/erickseniz" target="_blank" style="color:#ddd; text-decoration:none; display:inline-block; margin:5px 5px;">📘 Facebook</a>
                    <a href="https://wa.me/250780581260" target="_blank" style="color:#ddd; text-decoration:none; display:inline-block; margin:5px 0;">📱 WhatsApp</a>
                </div>
            </div>
        </div>
        <div style="text-align:center; margin-top:20px; padding-top:15px; border-top:1px solid #444; color:#ddd;">
            © <?php echo date("Y"); ?> NE Hotel. All Rights Reserved.
        </div>
    </div>

    <script src="active-nav.js"></script>
</body>

</html>